<?php 
  header( 'Location: http://www.ccafs-analogues.org/tool/');
?>
