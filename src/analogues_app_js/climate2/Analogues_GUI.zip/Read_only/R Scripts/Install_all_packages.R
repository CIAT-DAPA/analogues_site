packages=list.files(paste(getwd(),"/R and Analogues install/Install for Windows/Read_only/R packages",sep=""),full.names=TRUE)
install.packages(packages,repos=NULL)