######################################################################
################## LOAD PACKAGES AND ANALOGUES #######################
######################################################################
# for different operating systems
#if (length(grep("w32",version$os)) == 1) {
 # funx=function() {
#x11()
#}
#}
#funx()
require(gWidgets)
require(gWidgetsRGtk2)
options("guiToolkit"="RGtk2")
options(warn=-1)
data(zones)
data(sim_index_table)

#---------------------------------------------------------------------
# Calc_sim_functions ## delete when environment issues are sorted
#---------------------------------------------------------------------
grun_analoguesi <-
  function(){
    enabled(.win)=F
    svalue(.sb)="Loading parameters..."
    
    ##delete old folder
    if(file.exists(paste(getwd(),"/Results/",svalue(.sitei),"_",svalue(.direci),sep=""))){
      file.remove(list.files(paste(getwd(),"/Results/",svalue(.sitei),"_",svalue(.direci),"/",sep=""),full.names=T))
    } else {
      dir.create(paste(getwd(),"/Results/",svalue(.sitei),"_",svalue(.direci),"/",sep=""))
    }
    
    
    params = createParameters(x=as.numeric(svalue(.longi)),
                              y=as.numeric(svalue(.lati)),
                              method="ccafs",
                              direction=svalue(.direci),
                              period=c(svalue(.p1i),svalue(.p2i)),
                              scenario=c(svalue(.scen1i),svalue(.scen2i)),
                              model=c(svalue(.model1i),svalue(.model2i)),
                              vars=c(svalue(.var1i),svalue(.var2i)),
                              weights=c(as.numeric(svalue(.wt1i)),if(svalue(.wt2i)=="-"){0}else{as.numeric(svalue(.wt2i))}),
                              ndivisions=c(if(svalue(.var1i)=="tmean"|svalue(.var1i)=="prec")12 else(1),if(svalue(.var2i)=="tmean"|svalue(.var2i)=="prec")12 else(1)),
                              growing.season=if(svalue(.gs3i)=="-"){
                                c(which(month.abb==svalue(.gs1i)),which(month.abb==svalue(.gs2i)))
                              }else {
                                c(which(month.abb==svalue(.gs1i)),which(month.abb==svalue(.gs2i)),which(month.abb==svalue(.gs3i)),which(month.abb==svalue(.gs4i)))},
                              rotation=svalue(.roti),
                              zones=c(unlist(strsplit(svalue(.di1i),"_"))[1],unlist(strsplit(svalue(.di2i),"_"))[1]),
                              resolution=c(if(length(unlist(strsplit(svalue(.di1i),"_")))==3)paste(unlist(strsplit(svalue(.di1i),"_"))[2],"_",unlist(strsplit(svalue(.di1i),"_"))[3],sep="") else(unlist(strsplit(svalue(.di1i),"_"))[2]),if(length(unlist(strsplit(svalue(.di2i),"_")))==3)paste(unlist(strsplit(svalue(.di2i),"_"))[2],"_",unlist(strsplit(svalue(.di2i),"_"))[3],sep="") else(unlist(strsplit(svalue(.di2i),"_"))[2])),
                              env.data=paste(getwd(),"/Data",sep=""),
                              outfile=paste(getwd(),"/Results",sep=""),
                              ext=".tif",
                              threshold=0)
    if(svalue(.var2i)=="-"){  
      params$vars=params$vars[1]
      params$weights=params$weights[1]
      params$ndivisions=params$ndivisions[1]
    }
    print(paste("Input parameters for ",svalue(.sitei)," ",svalue(.direci),":",sep=""))
    print(params)
    svalue(.sb)="Calculating climatic similarity..."
    ###
    infotile = zones[which(row.names(zones) == paste(params$zones[1], "_", params$resolution[1], sep = "")), ]
    total_tiles = (infotile$NCOLS_TILES * infotile$NROWS_TILES) - 1
    val_ref = ref_vals(params)
    .val_ref<<-val_ref
    wrapper = function(i) {
      training_targ = loadData_targ(params, i)
      if (params$rotation == "none") {## | sum(!is.na(training_targ[[1]][, 1])) <= 100necessary??
        training_targ = training_targ
      } else {
        training_targ = rota_stack(val_ref, training_targ, params)
      }
      return(similarity(training_targ, val_ref, params))
    }
    infotile_2 = zones[which(row.names(zones) == paste(params$zones[2], "_", params$resolution[2], sep = "")), ]
    total_tiles_2 = (infotile_2$NCOLS_TILES * infotile_2$NROWS_TILES) - 1
    if (total_tiles_2 == 0){
      merged_tiles= wrapper(total_tiles_2)[[1]]
    }else{
      sfInit(parallel = T, cpus = if (total_tiles_2<=25){total_tiles_2 + 1}else{26})
      sfExport("params")
      sfExport("val_ref")
      sfExport("sim_index_table")
      sfLibrary(stringr)
      sfLibrary(raster)
      sfLibrary(Analogues)
      cat(paste("Calculating...\n"))
      res_tiles=sfLapply(0:total_tiles_2,fun = wrapper)
      sfStop()
      cat("Merging tiles...\n")
      if(length(res_tiles)>140){
        
        m1=res_tiles[1:100]           ; m1=do.call(merge,m1)
        m2=res_tiles[101:length(res_tiles)]; m2=do.call(merge,m2)
        merged_tiles=c(m1,m2)
        merged_tiles=do.call(merge,merged_tiles)
      }else{
        merged_tiles=do.call(merge,res_tiles)
      }
    }
    
    cat("Writing raster...\n")
    .raw_resi<<-merged_tiles
    writeRaster(merged_tiles,paste(getwd(),"/Results/",svalue(.sitei),"_",svalue(.direci),"/",svalue(.sitei),"_",svalue(.direci),".tif",sep=""),overwrite=TRUE)
    names(merged_tiles)=paste(svalue(.sitei),"_",svalue(.direci),sep="")
    KML(merged_tiles,paste(getwd(),"/Results/",svalue(.sitei),"_",svalue(.direci),"/",svalue(.sitei),"_",svalue(.direci),".kml",sep=""),overwrite=TRUE)
    
    x=  SpatialPointsDataFrame(matrix(c(as.numeric(svalue(.longi)),as.numeric(svalue(.lati))),nrow=1,ncol=2),data=data.frame(NA))
    names(x)=svalue(.sitei)
    writeOGR(x, paste(getwd(),"/Results/",svalue(.sitei),"_",svalue(.direci),"/",svalue(.sitei),".kml",sep=""), layer="reference marker", driver="KML") 
    
    cat("Extracting tmean and prec at the reference site...\n")
    svalue(.sb)="Extracting tmean and prec at the reference site..."
    ggraph_refi()
    
    
    ##soils
    .lats  <<- as.numeric(svalue(.lati))
    .longs <<- as.numeric(svalue(.longi))
    .dir1s <<- svalue(.di1i)
    .dir2s <<- svalue(.di2i)
    
    
    svalue(.sb)=paste("Analysis finished. Work through '1B Basic run results' to investigate results. Results exported to:\n",getwd(),"/Results/",svalue(.sitei),"_",svalue(.direci),"/",svalue(.sitei),"_",svalue(.direci),".tif",sep="")
    galert("Analysis finished. \nWork through '1B Basic run results' to investigate results.",delay=3)
    enabled(.win)=T
    enabled(.bbr)=T
    svalue(.nb)<-3
  }


grun_analoguesj <-
  function(){
    enabled(.win)=F
    
    ##delete old folder
    if(file.exists(paste(getwd(),"/Results/",svalue(.sitej),"_FOTF",sep=""))){
      file.remove(list.files(paste(getwd(),"/Results/",svalue(.sitej),"_FOTF/",sep=""),full.names=T,recursive=T))
    } else {
      dir.create(paste(getwd(),"/Results/",svalue(.sitej),"_FOTF/Individual_GCMs",sep=""),recursive=T)
    }
    
    params = createParameters(x=as.numeric(svalue(.longj)),
                              y=as.numeric(svalue(.latj)),
                              method="ccafs",
                              direction="backwards",
                              period=c(svalue(.p1j),"1960_1990"),
                              scenario=c(svalue(.scen1j),"baseline"),
                              model=c("dummy-FOTF","current"),
                              vars=c(svalue(.var1j),svalue(.var2j)),
                              weights=c(as.numeric(svalue(.wt1j)),if(svalue(.wt2j)=="-"){0}else{as.numeric(svalue(.wt2j))}),
                              ndivisions=c(if(svalue(.var1j)=="tmean"|svalue(.var1j)=="prec")12 else(1),if(svalue(.var2j)=="tmean"|svalue(.var2j)=="prec")12 else(1)),
                              growing.season=if(svalue(.gs3j)=="-"){
                                c(which(month.abb==svalue(.gs1j)),which(month.abb==svalue(.gs2j)))
                              }else {
                                c(which(month.abb==svalue(.gs1j)),which(month.abb==svalue(.gs2j)),which(month.abb==svalue(.gs3j)),which(month.abb==svalue(.gs4j)))},
                              rotation=svalue(.rotj),
                              zones=c(unlist(strsplit(svalue(.di1j),"_"))[1],unlist(strsplit(svalue(.di2j),"_"))[1]),
                              resolution=c(if(length(unlist(strsplit(svalue(.di1j),"_")))==3)paste(unlist(strsplit(svalue(.di1j),"_"))[2],"_",unlist(strsplit(svalue(.di1j),"_"))[3],sep="") else(unlist(strsplit(svalue(.di1j),"_"))[2]),if(length(unlist(strsplit(svalue(.di2j),"_")))==3)paste(unlist(strsplit(svalue(.di2j),"_"))[2],"_",unlist(strsplit(svalue(.di2j),"_"))[3],sep="") else(unlist(strsplit(svalue(.di2j),"_"))[2])),
                              env.data=paste(getwd(),"/Data",sep=""),
                              outfile=paste(getwd(),"/Results",sep=""),
                              ext=".tif",
                              threshold=0)
    if(svalue(.var2j)=="-"){  
      params$vars=params$vars[1]
      params$weights=params$weights[1]
      params$ndivisions=params$ndivisions[1]
    }
    print(paste("Input parameters for ",svalue(.sitej)," FOTF run:",sep=""))
    print(params)
    
    svalue(.sb)="Loading required data..."
    ######
    infotile = zones[which(row.names(zones) == paste(params$zones[1], "_", params$resolution[1], sep = "")), ]
    total_tiles = (infotile$NCOLS_TILES * infotile$NROWS_TILES) - 1
    models=list.files(paste(params$env.data,"/",params$scenario[1],"/",params$zones[1],"_",params$resolution[1],sep=""))
    
    ## parallel
    refs_parallel=function(i){
      params$model[1]=models[i]
      return(ref_vals(params))
    }     
    
    wrapper = function(i) {
      training_targ = loadData_targ(params, i)
      if (params$rotation == "none") {## | sum(!is.na(training_targ[[1]][, 1])) <= 100necessary??
        training_targ = training_targ
      } else {
        training_targ = rota_stack(val_ref, training_targ, params)
      }
      return(similarity(training_targ, val_ref, params))
    }
    
    infotile_2 = zones[which(row.names(zones) == paste(params$zones[2], "_", params$resolution[2], sep = "")), ]
    total_tiles_2 = (infotile_2$NCOLS_TILES * infotile_2$NROWS_TILES) - 1
    
    sfInit(parallel = T, cpus = 4)
    sfExport("params")
    sfExport("models")
    sfExport("sim_index_table")
    sfExport("zones")
    sfLibrary(stringr)
    sfLibrary(raster)
    sfLibrary(Analogues)
    cat("Extracting ref vals...\n")
    svalue(.sb)="Extracting reference site values..."
    val_refs_fotf=sfLapply(1:length(models),fun = refs_parallel)
    sfStop()
    
    #val_refs_fotf ##export as table
    
    if (total_tiles_2 == 0){
      for (m in 1:length(models)){
        cat(paste("Calculating similarity for",models[m], "...\n"))
        if(m>2){calc_time=(prc3-prc1)[3]*(length(models)-m+1)}
        svalue(.sb)=paste("Calculating similarity for model number ",m," of ",length(models),if(m>2){paste(". Estimated ",floor(calc_time/60),":", sprintf( "%02d", round(calc_time-floor(calc_time/60)*60-0.5)) ," minutes remaining", sep="")}else{". Calculating processing time"} ,"...",sep="")
        prc1=proc.time()
        val_ref=val_refs_fotf[[m]]        
        merged_tiles= wrapper(0)
        writeRaster(merged_tiles, paste(params$outfile, "/",svalue(.sitej),"_FOTF/Individual_GCMs/" ,models[m],".tif", sep = ""), overwrite = TRUE)
        prc3=proc.time()
      }
    }else{
      sfInit(parallel = T, cpus = if (total_tiles_2<=25){total_tiles_2 + 1}else{26})
      sfExport("params")
      sfExport("val_refs_fotf")
      sfExport("sim_index_table")
      sfLibrary(stringr)
      sfLibrary(raster)
      sfLibrary(Analogues)
      for (m in 1:length(models)){
        cat("Calculating similarity for",models[m], "...\n")
        if(m>2){calc_time=(prc3-prc1)[3]*(length(models)-m+1)}
        svalue(.sb)=paste("Calculating similarity for model number ",m," of ",length(models),if(m>2){paste(". Estimated ",floor(calc_time/60),":", sprintf( "%02d", round(calc_time-floor(calc_time/60)*60-0.5)) ," minutes remaining", sep="")}else{". Calculating processing time"} ,"...",sep="")
        prc1=proc.time()
        val_ref=val_refs_fotf[[m]]        
        res_tiles=sfLapply(0:total_tiles_2,fun = wrapper)
        prc2=proc.time()
        svalue(.sb)=paste("Calculating similarity for model number ",m," of ",length(models),if(m>2){paste(". Estimated ",floor((calc_time-(prc2-prc1)[3])/60),":",sprintf( "%02d",round((calc_time-(prc2-prc1)[3])-floor((calc_time-(prc2-prc1)[3])/60)*60-0.5))," minutes remaining", sep="")}else{". Calculating processing time"} ,"...",sep="")
        if(length(res_tiles)>140){
          m1=res_tiles[1:100]                 ; m1=do.call(merge,m1)
          m2=res_tiles[101:length(res_tiles)]; m2=do.call(merge,m2)
          merged_tiles=c(m1,m2)
          merged_tiles=do.call(merge,merged_tiles)
        }else{
          merged_tiles=do.call(merge,res_tiles)
        }
        writeRaster(merged_tiles, paste(params$outfile, "/",svalue(.sitej),"_FOTF/Individual_GCMs/",models[m],".tif", sep = ""), overwrite = TRUE)
        prc3=proc.time()
      }
      sfStop()
    }
    
    x=  SpatialPointsDataFrame(matrix(c(as.numeric(svalue(.longj)),as.numeric(svalue(.latj))),nrow=1,ncol=2),data=data.frame(NA))
    names(x)=svalue(.sitej)
    writeOGR(x, paste(getwd(),"/Results/",svalue(.sitej),"_FOTF/",svalue(.sitej),".kml",sep=""), layer="reference marker", driver="KML") 
        
    
    ###
    cat("Extracting tmean and prec at the reference site...\n")
    svalue(.sb)="Extracting tmean and prec at the reference site..."
    ggraph_refj()
    ####
    
    
    ##soils
    .lats  <<- as.numeric(svalue(.latj))
    .longs <<- as.numeric(svalue(.longj))
    .dir1s <<- svalue(.di1j)
    .dir2s <<- svalue(.di2j)
    
    
    svalue(.sb)="Analysis finished. Work through '2B FOTF run results' to analyse results."
    galert("Analysis finished. \nWork through '2B FOTF run results' to analyse results.",delay=3)
    enabled(.win)=T
    enabled(.ffotf)=T
    svalue(.nb)<-5
  }


######################################################################
########################### INTERFACE ################################
######################################################################
### interface

.win <- gwindow("Analogues R interface v1.0", visible=F ,width = 600)
.nb = gnotebook(cont=.win,expand=T,tab.pos = 2)

#---------------------------------------------------------------------
# Landing page
#---------------------------------------------------------------------
.welcome=ggroup(horizontal = F,label="Welcome",container=.nb)
gimage("Welcome.png",dirname=paste(getwd(),"/R and Analogues install/Install for Windows/Read_only/R Scripts",sep=""), size="dialog", container=.welcome)

#---------------------------------------------------------------------
# Basic run load parameters
#---------------------------------------------------------------------

.br=glayout(homogeneous =F,cont=.nb,spacing=1,label="1A Basic run",expand=T) 

## Select a reference site 
.br[2,1:3]=(.k=gframe("Select a reference site",container=.br,horizontal = F,expand=T))
.br1=glayout(homogeneous=F,cont=.k,spacing=1,expand=T) 

## space
.br1[3,1:3]=glabel("")

## Site details
.br1[4,1]=glabel("Site ID",container=.br1,cont=.k)
.br1[4,2:3]=(.sitei=gedit("Site name"))

## select shapefile
.shape_dir_refi=paste(getwd(),"/Shapefiles/shape_dir_refi.csv",sep="")

.br1[6,1]=glabel("Select a shapefile",container=.br1,cont=.k)
.br1[6,2:3]=(.shp_refi=gfilebrowse(if(file.exists(.shape_dir_refi)){
  .shape_dir_refi=read.csv(.shape_dir_refi)
  .shape_dir_refi=gsub("'","",as.character(.shape_dir_refi[1,2]))
  .text = .shape_dir_refi
} else{"Select a shapefile..."}))


## select reference site
.br1[8,2:3]=(.sel_refi=gbutton(text="Select reference site",container=.br1,handler = function(.k,...){gsel_refi() } ))

if(!file.exists(.shape_dir_refi)){enabled(.sel_refi)=F}

addHandlerChanged(.shp_refi, handler=function(h,...) {
  write.csv(as.data.frame(svalue(.shp_refi)),paste(getwd(),"/Shapefiles/shape_dir_refi.csv",sep="")) 
  enabled(.sel_refi)=T
})

## coordinates
.br1[10,1]=glabel("Coordinates (dd)",container=.br1,cont=.k)
.br1[10,2]=(.lati=gedit(initial.msg="lat."))
.br1[10,3]=(.longi=gedit(initial.msg="long."))

## space
.br1[12,1:3]=glabel("")

##enter parameters
.br[14,1:3]=(.k=gframe("Enter Parameters",container=.br,horizontal = F,expand=T))
.br2=glayout(homogeneous=F,cont=.k,spacing=1,expand=T) 

## ref and search
.br2[16,2]=glabel("Reference site",container=.br2,cont=.k)
.br2[16,3]=glabel("Search area",container=.br2,cont=.k)

## Data_input
.br2[18,1]=glabel("Input data",container=.br2,cont=.k)
.scenario_list=list.files(paste(getwd(),"/Data",sep=""))
.br2[18,2]=(.di1i=gdroplist(unique(c(list.files(paste(getwd(),"/Data/",.scenario_list,sep="")))),container=.br2,cont=.k,expand=T))
.br2[18,3]=(.di2i=gdroplist(unique(c(list.files(paste(getwd(),"/Data/",.scenario_list,sep="")))),container=.br2,cont=.k,expand=T))

## Direction
.br2[20,1]=glabel("Direction",container=.br2,cont=.k)
.br2[20,2:3]=(.direci=gdroplist(c("forwards","backwards","none"),selected = 2,container=.br2,cont=.k,expand=T))

## Scenario
.br2[22,1]=glabel("Scenario",container=.br2,cont=.k)
.br2[22,2]=(.scen1i=gdroplist(list.files(paste(getwd(),"/Data",sep=""))[-which(list.files(paste(getwd(),"/Data",sep=""))=="baseline")],selected = 1,container=.br2,cont=.k,expand=T))
.br2[22,3]=(.scen2i=gdroplist(c("baseline"),selected = 1,container=.br2,cont=.k,expand=T))

## Model
.br2[24,1]=glabel("Model",container=.br2,cont=.k)
.br2[24,2]=(.model1i=gdroplist(c(list.files(paste(getwd(),"/Data/",svalue(.scen1i),"/",svalue(.di1i),sep=""))),selected = which(list.files(paste(getwd(),"/Data/",svalue(.scen1i),"/",svalue(.di1i),sep=""))=="ensemble"),container=.br2,cont=.k,expand=T))
.br2[24,3]=(.model2i=gdroplist(c("current"),selected = 1,container=.br2,cont=.k,expand=T))

## period
.br2[26,1]=glabel("Period",container=.br2,cont=.k)
.br2[26,2]=(.p1i=gdroplist(c(list.files(paste(getwd(),"/Data/",svalue(.scen1i),"/",svalue(.di1i),"/",svalue(.model1i),sep=""))),selected = 1,container=.br2,cont=.k,expand=T))
.br2[26,3]=(.p2i=gdroplist(c("1960_1990"),selected = 1,container=.br2,cont=.k,expand=T))

## handler to select scenario from direction
addHandlerChanged(.direci, handler=function(h,...) {
  if(svalue(.direci)=="backwards"){
    mods=list.files(paste(getwd(),"/Data",sep=""))[-which(list.files(paste(getwd(),"/Data",sep=""))=="baseline")]
    .scen1i[]<-mods 
    svalue(.scen1i)<-.scen1i[1]
    .scen2i[]<-"baseline" 
    svalue(.scen2i)<-"baseline"
  }  else {
    if(svalue(.direci)=="forwards"){
      mods=list.files(paste(getwd(),"/Data",sep=""))[-which(list.files(paste(getwd(),"/Data",sep=""))=="baseline")]
      .scen1i[]<-"baseline" 
      svalue(.scen1i)<-"baseline"
      .scen2i[]<-mods 
      svalue(.scen2i)<-mods[1]      
    }  else{
      mods=list.files(paste(getwd(),"/Data",sep=""))
      .scen1i[]<-mods 
      svalue(.scen1i)<-"baseline"
      .scen2i[]<-"baseline"
      svalue(.scen2i)<-"baseline"
    }
  }
})

#handler to make sure scenarios are the same for non-directional analyses
addHandlerChanged(.scen1i, handler=function(h,...) {
  if(!is.null(svalue(.scen1i))&& !is.null(svalue(.direci))){
    if(svalue(.scen1i)=="baseline" && svalue(.direci)=="none"){
      .scen2i[]<-"baseline"
      svalue(.scen2i)<-"baseline"
    }else{
      if(!svalue(.scen1i)=="baseline" && svalue(.direci)=="none"){
        .scen2i[]<-.scen2i[]<-.scen1i[-(which(.scen1i[]=="baseline"))]
        svalue(.scen2i)<-svalue(.scen1i)
      }}
  }
})

## handler to set models from scenario for ref site
addHandlerChanged(.scen1i, handler=function(h,...) {
  if(!is.null(svalue(.scen1i))){
    .model1i[]<-list.files(paste(getwd(),"/Data/",svalue(.scen1i),"/",svalue(.di1i),sep=""))
    svalue(.model1i)<-if(svalue(.scen1i)=="baseline")(
      .model1i[1]
    )else(
      if("ensemble" %in% .model1i[])("ensemble")else(.model1i[1])
    )
  }
})

## handler to set models from scenario for search area
addHandlerChanged(.scen2i, handler=function(h,...) {
  if(!is.null(svalue(.scen2i))){
    .model2i[]<-list.files(paste(getwd(),"/Data/",svalue(.scen2i),"/",svalue(.di2i),sep=""))
    svalue(.model2i)<-if(svalue(.scen2i)=="baseline")(
      .model2i[1]
    )else(
      if("ensemble" %in% .model2i[])("ensemble")else(.model2i[1])
    )
  }
})

## handler to set period from models for ref site
addHandlerChanged(.model1i, handler=function(h,...) {
  if(!is.null(svalue(.model1i))){
    .p1i[]<-list.files(paste(getwd(),"/Data/",svalue(.scen1i),"/",svalue(.di1i),"/",svalue(.model1i),sep=""))
    svalue(.p1i)<-.p1i[1]
  }
})


## handler to set period from models for search area
addHandlerChanged(.model2i, handler=function(h,...) {
  if(!is.null(svalue(.model2i))){  
    .p2i[]<-list.files(paste(getwd(),"/Data/",svalue(.scen2i),"/",svalue(.di2i),"/",svalue(.model2i),sep=""))
    svalue(.p2i)<-.p2i[1]
  }
})



## space
.br2[28,1:3]=glabel("")

## Variable
.br2[30,1]=glabel("Variable",container=.br2,cont=.k)
.br2[30,2]=(.var1i=gdroplist(c("prec","tmean",paste("bio_",1:19,sep="")),selected = 2,container=.br2,cont=.k,expand=T))
.br2[30,3]=(.var2i=gdroplist(c("-","prec","tmean",paste("bio_",1:19,sep="")),selected = 2,container=.br2,cont=.k,expand=T))

## weights
.br2[32,1]=glabel("Weights",container=.br2,cont=.k)
.br2[32,2]=(.wt1i=gedit(0.5))
.br2[32,3]=(.wt2i=gedit(0.5))

## handler to set second weight to zero for only one variable selected
addHandlerChanged(.var2i, handler=function(h,...) {
  if(svalue(.var2i)=="-"){  
    svalue(.wt2i)<-"-"
    enabled(.wt2i)<-FALSE
    svalue(.wt1i)<-1.0
  }else{
    svalue(.wt2i)<-0.5
    svalue(.wt1i)<-0.5
    enabled(.wt2i)<-TRUE
  }
})

## handlers to set sum of weights = 1
addHandlerKeystroke(.wt1i, handler=function(h,...) {
  if(enabled(.wt2i)){  
    if(abs(as.numeric(svalue(.wt1i)))<=1){
      svalue(.wt2i)<-1-as.numeric(svalue(.wt1i))
    }else{
      svalue(.wt1i)<-0.5
      svalue(.wt2i)<-0.5
    }
  }else{
    svalue(.wt1i)<-1
  }
})

addHandlerKeystroke(.wt2i, handler=function(h,...) {
  if(abs(as.numeric(svalue(.wt2i)))<=1){
    svalue(.wt1i)<-1-as.numeric(svalue(.wt2i))
  }else{
    svalue(.wt1i)<-0.5
    svalue(.wt2i)<-0.5
  }
})


## space
.br2[34,1:3]=glabel("")

## Growing season
.br2[36,1]=glabel("Growing season",container=.br2,cont=.k)
.br2[36,2]=(.gs1i=gdroplist(month.abb,selected = 1,container=.br2,cont=.k,expand=T))
.br2[36,3]=(.gs2i=gdroplist(month.abb,selected = 12,container=.br2,cont=.k,expand=T))

.br2[38,1]=glabel("Growing season 2",container=.br2,cont=.k)
.br2[38,2]=(.gs3i=gdroplist(c(month.abb,"-"),selected = 13,container=.br2,cont=.k,expand=T))
.br2[38,3]=(.gs4i=gdroplist(c(month.abb,"-"),selected = 13,container=.br2,cont=.k,expand=T))

## Rotation
.br2[40,1]=glabel("Rotation",container=.br2,cont=.k)
.br2[40,2]=(.roti=gdroplist(c("none","prec","tmean","both"),selected = 1,container=.br2,cont=.k,expand=T))

## Handlers to remove growing season and rotation otions from bioclim only searches:
addHandlerChanged(.var1i, handler=function(h,...) {
  if(sum(c(grep("prec",str_c(svalue(.var1i),svalue(.var2i))),grep("tmean",str_c(svalue(.var1i),svalue(.var2i)))))==0){  
    enabled(.gs1i)<-FALSE
    enabled(.gs2i)<-FALSE
    enabled(.gs3i)<-FALSE
    enabled(.gs4i)<-FALSE
    svalue(.roti)<-"none"
    enabled(.roti)<-FALSE    
  }else{
    enabled(.gs1i)<-TRUE
    enabled(.gs2i)<-TRUE
    enabled(.gs3i)<-TRUE
    enabled(.gs4i)<-TRUE
    enabled(.roti)<-TRUE
  }
})
addHandlerChanged(.var2i, handler=function(h,...) {
  if(sum(c(grep("prec",str_c(svalue(.var1i),svalue(.var2i))),grep("tmean",str_c(svalue(.var1i),svalue(.var2i)))))==0){  
    enabled(.gs1i)<-FALSE
    enabled(.gs2i)<-FALSE
    enabled(.gs3i)<-FALSE
    enabled(.gs4i)<-FALSE
    svalue(.roti)<-"none"
    enabled(.roti)<-FALSE    
  }else{
    enabled(.gs1i)<-TRUE
    enabled(.gs2i)<-TRUE
    enabled(.gs3i)<-TRUE
    enabled(.gs4i)<-TRUE
    enabled(.roti)<-TRUE
  }
})

## space
.br2[42,1:3]=glabel("")

# Run
.br[44,3]=gbutton(text="Run",container=.br,handler = function(.k,...){grun_analoguesi() } )


#---------------------------------------------------------------------
# Basic results 
#---------------------------------------------------------------------
.bbr=glayout(homogeneous =F,cont=.nb,spacing=1,label="1B Basic run results",expand=T) 


##select shapefile
.shape_diri=paste(getwd(),"/Shapefiles/shape_diri.csv",sep="")

.bbr[4,1]=glabel("Select a shapefile",container=.bbr)
.bbr[4,2]=(.shpi=gfilebrowse(if(file.exists(.shape_diri)){
  .shape_diri=read.csv(.shape_diri)
  .shape_diri=gsub("'","",as.character(.shape_diri[1,2]))
  .text = .shape_diri
}else{
  text = "Select a shapefile..."
}))

addHandlerChanged(.shpi, handler=function(h,...) {
  write.csv(as.data.frame(svalue(.shpi)),paste(getwd(),"/Shapefiles/shape_diri.csv",sep="")) 
})

##Space
.bbr[5,1]=glabel("")


##plot basic results
.bbr[10,1]=glabel("Plot raw results",container=.bbr,cont=.k)
.bbr[10,2]=gbutton(text="Plot",handler = function(.k,...){gplot_rawi() } )

##Space
.bbr[12,1]=glabel("")

##select threshold
.bbr[16,1]=glabel("Select threshold",container=.bbr,cont=.k)
.bbr[16,2]=(.threshi=gedit(0.95))

##apply threshold
.bbr[18,2]=gbutton(text="apply",handler = function(.k,...){gplot_threshi() } )

##Space
.bbr[24,1]=glabel("")

## Selecting analogue sites 
.bbr[26,1:2]=(.k=gframe("Selecting analogue sites",container=.bbr,horizontal = F,expand=T))

##zoom to area
.bbr[28,1]=glabel("From map (zoom level)",container=.bbr,cont=.k)
if(!svalue(.shpi)=="Select a shapefile..."){
  .sh=gsub("'","",svalue(.shpi))
  .sh1=shapefile(.sh)
  .bbr[28,2]=(.areai=gdroplist(if(colnames(head(.sh1))[1]=="GADMID"||colnames(head(.sh1))[1]=="ID_0"){
    c("No zoom","State","District")
  }else{
    if(colnames(head(.sh1))[5]=="ADM0_CODE"){
      c("No zoom","Country")
    }
  },selected=1,container=.bbr,expand=T))
}else{
  .bbr[28,2]=(.areai=gdroplist("No zoom",selected=1,container=.bbr,expand=T))
} 

addHandlerChanged(.shpi, handler=function(h,...) {
  .sh=gsub("'","",svalue(.shpi))
  .sh1=shapefile(.sh)  
  if(colnames(head(.sh1))[1]=="GADMID"||colnames(head(.sh1))[1]=="ID_0"){
    .areai[]<-c("No zoom","State","District")
    svalue(.areai)<-"No zoom"
  }else{
    if(colnames(head(.sh1))[5]=="ADM0_CODE"){
      .areai[]<-c("No zoom","Country")
      svalue(.areai)<-"No zoom"
    }else{
    .areai[]<-"No zoom"
    svalue(.areai)<-"No zoom"
  }}
})

## select analogue site
.bbr[30,2]=(.seli1=gbutton(text="GO",handler = function(.k,...){gsel_analoguei() } ))
##Space
.bbr[32,1]=glabel("")

##Analogue by coordinates
.bbr[34,1]=glabel("From coordinates (dd)",container=.bbr,cont=.k)
.bbr[34,2]=(.lat_abc_i=gedit(initial.msg="lat."))
.bbr[36,2]=(.long_abc_i=gedit(initial.msg="long."))
.bbr[38,2]=(.seli2=gbutton(text="GO",container=.bbr,handler = function(.k,...){ganalogue_by_coords_i() } ))


##Space
.bbr[40,1]=glabel("")

#.bbr[42,2]=gbutton(text="Clear all graphs",container=.bbr,handler = function(.k,...){graphics.off()} )


#---------------------------------------------------------------------
# Farms of the Future
#---------------------------------------------------------------------
.fotf=glayout(homogeneous =F,cont=.nb,spacing=1,label="2A FOTF run",expand=T) 

## enter parameters 
.fotf[2,1:3]=(.k=gframe("Select a reference site",container=.fotf,horizontal = F,expand=T))
.fotf1=glayout(homogeneous=F,cont=.k,spacing=1,expand=T) 

## space
.fotf1[3,1:3]=glabel("")

## Site details
.fotf1[4,1]=glabel("Site ID",container=.fotf1,cont=.k)
.fotf1[4,2:3]=(.sitej=gedit("Site name"))

## select shapefile
.shape_dir_refj=paste(getwd(),"/Shapefiles/shape_dir_refj.csv",sep="")

.fotf1[6,1]=glabel("Select a shapefile",container=.fotf1,cont=.k)
.fotf1[6,2:3]=(.shp_refj=gfilebrowse(if(file.exists(.shape_dir_refj)){
  .shape_dir_refj=read.csv(.shape_dir_refj)
  .shape_dir_refj=gsub("'","",as.character(.shape_dir_refj[1,2]))
  .text = .shape_dir_refj
} else{text = "Select a shapefile..."}))

## select reference site
.fotf1[8,2:3]=(.sel_refj=gbutton(text="Select reference site",container=.fotf1,handler = function(.k,...){gsel_refj() } ))

if(!file.exists(.shape_dir_refj)){enabled(.sel_refj)=F}

addHandlerChanged(.shp_refj, handler=function(h,...) {
  write.csv(as.data.frame(svalue(.shp_refj)),paste(getwd(),"/Shapefiles/shape_dir_refj.csv",sep="")) 
  enabled(.sel_refj)=T
})

## coordinates
.fotf1[10,1]=glabel("Coordinates (dd)",container=.fotf1,cont=.k)
.fotf1[10,2]=(.latj=gedit(initial.msg="lat."))
.fotf1[10,3]=(.longj=gedit(initial.msg="long."))

## space
.fotf1[12,1:3]=glabel("")

##enter parameters
.fotf[14,1:3]=(.k=gframe("Enter Parameters",container=.fotf,horizontal = F,expand=T))
.fotf2=glayout(homogeneous=F,cont=.k,spacing=1,expand=T) 

## space
.fotf2[16,2]=glabel("Reference site",container=.fotf2,cont=.k)
.fotf2[16,3]=glabel("Search area",container=.fotf2,cont=.k)

## Data_input
.fotf2[18,1]=glabel("Input data",container=.fotf2,cont=.k)
.fotf2[18,2]=(.di1j=gdroplist(c(list.files(paste(getwd(),"/Data/baseline",sep=""))),selected =1,container=.fotf2,cont=.k,expand=T))
.fotf2[18,3]=(.di2j=gdroplist(c(list.files(paste(getwd(),"/Data/baseline",sep=""))),selected =1,container=.fotf2,cont=.k,expand=T))

## Direction
.fotf2[20,1]=glabel("Direction",container=.fotf2,cont=.k)
.fotf2[20,2:3]=(.gry1=gdroplist("backwards",container=.fotf2,cont=.k))
enabled(.gry1)<-FALSE

## Scenario
.fotf2[22,1]=glabel("Scenario",container=.fotf2,cont=.k)
.fotf2[22,2]=(.scen1j=gdroplist(list.files(paste(getwd(),"/Data",sep=""))[-which(list.files(paste(getwd(),"/Data",sep=""))=="baseline")],selected = 1,container=.fotf2,cont=.k,expand=T))
.fotf2[22,3]=(.gry2=gdroplist("baseline",container=.fotf2,cont=.k))
enabled(.gry2)<-FALSE


## Model
.fotf2[24,1]=glabel("Model",container=.fotf2,cont=.k)
.fotf2[24,2]=(.gry3=gdroplist("All available models",container=.fotf2,cont=.k))
.fotf2[24,3]=(.gry4=gdroplist("current",container=.fotf2,cont=.k))
enabled(.gry3)<-FALSE
enabled(.gry4)<-FALSE

## Period
.fotf2[26,1]=glabel("Period",container=.fotf2,cont=.k)
.fotf2[26,2]=(.p1j=gdroplist(list.files(list.files(paste(getwd(),"/Data/",svalue(.scen1j),"/",svalue(.di1j),sep=""),full.names=TRUE)[1]),selected = 1,container=.fotf2,cont=.k,expand=T))
.fotf2[26,3]=(.gry5=gdroplist("1960_1990",container=.fotf2,cont=.k))
enabled(.gry5)<-FALSE

##handlers for the FOTF runs
addHandlerChanged(.di1j, handler=function(h,...) {
  if(!is.null(svalue(.di1j))){
    .scen1j[]<-list.files(paste(getwd(),"/Data",sep=""))[-which(list.files(paste(getwd(),"/Data",sep=""))=="baseline")]
    svalue(.scen1j)<-.scen1j[1]
  }
})

addHandlerChanged(.scen1j, handler=function(h,...) {
  if(!is.null(svalue(.scen1j))){
    .p1j[]<-list.files(list.files(paste(getwd(),"/Data/",svalue(.scen1j),"/",svalue(.di1j),sep=""),full.names=TRUE)[1])
    svalue(.p1j)<-.p1j[1]
  }
})

## space
.fotf2[28,1:3]=glabel("")

## Variable
.fotf2[30,1]=glabel("Variable",container=.fotf2,cont=.k)
.fotf2[30,2]=(.var1j=gdroplist(c("prec","tmean",paste("bio_",1:19,sep="")),selected = 2,container=.fotf2,cont=.k,expand=T))
.fotf2[30,3]=(.var2j=gdroplist(c("-","prec","tmean",paste("bio_",1:19,sep="")),selected = 2,container=.fotf2,cont=.k,expand=T))

## weights
.fotf2[32,1]=glabel("Weights",container=.fotf2,cont=.k)
.fotf2[32,2]=(.wt1j=gedit(0.5))
.fotf2[32,3]=(.wt2j=gedit(0.5))

## handler to set second weight to zero for only one variable selected
addHandlerChanged(.var2j, handler=function(h,...) {
  if(svalue(.var2j)=="-"){  
    svalue(.wt2j)<-"-"
    enabled(.wt2j)<-FALSE
    svalue(.wt1j)<-1.0
  }else{
    svalue(.wt2j)<-0.5
    svalue(.wt1j)<-0.5
    enabled(.wt2j)<-TRUE
  }
})

## handlers to set sum of weights = 1
addHandlerKeystroke(.wt1j, handler=function(h,...) {
  if(enabled(.wt2j)){  
    if(abs(as.numeric(svalue(.wt1j)))<=1){
      svalue(.wt2j)<-1-as.numeric(svalue(.wt1j))
    }else{
      svalue(.wt1j)<-0.5
      svalue(.wt2j)<-0.5
    }
  }else{
    svalue(.wt1j)<-1
  }
})

addHandlerKeystroke(.wt2j, handler=function(h,...) {
    if(abs(as.numeric(svalue(.wt2j)))<=1){
    svalue(.wt1j)<-1-as.numeric(svalue(.wt2j))
  }else{
    svalue(.wt1j)<-0.5
    svalue(.wt2j)<-0.5
  }
})



## space
.fotf2[34,1:3]=glabel("")

## Growing season
.fotf2[36,1]=glabel("Growing season",container=.fotf2,cont=.k)
.fotf2[36,2]=(.gs1j=gdroplist(month.abb,selected = 1,container=.fotf2,cont=.k,expand=T))
.fotf2[36,3]=(.gs2j=gdroplist(month.abb,selected = 12,container=.fotf2,cont=.k,expand=T))

.fotf2[38,1]=glabel("Growing season 2",container=.fotf2,cont=.k)
.fotf2[38,2]=(.gs3j=gdroplist(c(month.abb,"-"),selected = 13,container=.fotf2,cont=.k,expand=T))
.fotf2[38,3]=(.gs4j=gdroplist(c(month.abb,"-"),selected = 13,container=.fotf2,cont=.k,expand=T))

## Rotation
.fotf2[40,1]=glabel("Rotation",container=.fotf2,cont=.k)
.fotf2[40,2]=(.rotj=gdroplist(c("none","prec","tmean","both"),selected = 1,container=.fotf2,cont=.k,expand=T))

## Handlers to remove growing season and rotation otions from bioclim only searches:
addHandlerChanged(.var1j, handler=function(h,...) {
  if(sum(c(grep("prec",str_c(svalue(.var1j),svalue(.var2j))),grep("tmean",str_c(svalue(.var1j),svalue(.var2j)))))==0){  
    enabled(.gs1j)<-FALSE
    enabled(.gs2j)<-FALSE
    enabled(.gs3j)<-FALSE
    enabled(.gs4j)<-FALSE
    svalue(.rotj)<-"none"
    enabled(.rotj)<-FALSE    
  }else{
    enabled(.gs1j)<-TRUE
    enabled(.gs2j)<-TRUE
    enabled(.gs3j)<-TRUE
    enabled(.gs4j)<-TRUE
    enabled(.rotj)<-TRUE
  }
})
addHandlerChanged(.var2j, handler=function(h,...) {
  if(sum(c(grep("prec",str_c(svalue(.var1j),svalue(.var2j))),grep("tmean",str_c(svalue(.var1j),svalue(.var2j)))))==0){  
    enabled(.gs1j)<-FALSE
    enabled(.gs2j)<-FALSE
    enabled(.gs3j)<-FALSE
    enabled(.gs4j)<-FALSE
    svalue(.rotj)<-"none"
    enabled(.rotj)<-FALSE    
  }else{
    enabled(.gs1j)<-TRUE
    enabled(.gs2j)<-TRUE
    enabled(.gs3j)<-TRUE
    enabled(.gs4j)<-TRUE
    enabled(.rotj)<-TRUE
  }
})

## space
.fotf2[42,1:3]=glabel("")

## Run
.fotf[44,3]=gbutton(text="Run",container=.fotf,handler = function(.k,...){grun_analoguesj() } )



#---------------------------------------------------------------------
# FOTF Results
#---------------------------------------------------------------------
.ffotf=glayout(homogeneous =F,cont=.nb,spacing=1,label="2B FOTF run results") 

##select shapefile
.shape_dirj=paste(getwd(),"/Shapefiles/shape_dirj.csv",sep="")

.ffotf[4,1]=glabel("Select a shapefile",container=.ffotf,cont=.k)
.ffotf[4,2]=(.shpj=gfilebrowse(if(file.exists(.shape_dirj)){
  .shape_dirj=read.csv(.shape_dirj)
  .shape_dirj=gsub("'","",as.character(.shape_dirj[1,2]))
  .text = .shape_dirj
}else{
"Select a shapefile..."
}))

addHandlerChanged(.shpj, handler=function(h,...) {
  write.csv(as.data.frame(svalue(.shpj)),paste(getwd(),"/Shapefiles/shape_dirj.csv",sep="")) 
})


##Space
.ffotf[5,1:3]=glabel("")

##plot raster stack of results
.ffotf[10,1]=glabel("Plot raw results",container=.ffotf,expand=T,cont=.k)
.ffotf[10,2]=gbutton(text="Plot",expand=T,container=.ffotf,handler = function(.k,...){gplot_rawj() } )

##Space
.ffotf[12,1:3]=glabel("")

## enter parameters 
.ffotf[14,1:2]=(.k=gframe("Select a threshold and agreement",container=.ffotf))

##select threshold
.ffotf[16,1]=glabel("Select threshold",container=.ffotf,cont=.k)
.ffotf[16,2]=(.threshj=gedit(0.95))

##select agreement
.ffotf[18,1]=glabel("Select agreement",container=.ffotf,cont=.k)
.ffotf[18,2]=(.agreej=gedit(10))

##apply threshold and agreement
.ffotf[20,2]=gbutton(text="apply",container=.ffotf,handler = function(.k,...){gplot_threshj() } )

##Space
.ffotf[22,1:3]=glabel("")

## Investigating analogue sites 
.ffotf[24,1:2]=(.k=gframe("Selecting analogue sites",container=.ffotf))

##plot individual raster from results stack
.ffotf[26,1]=glabel("Result to use",container=.ffotf,cont=.k)
.models=c("FOTF",list.files(paste(getwd(),"/Data/",svalue(.scen1j),"/",unlist(strsplit(svalue(.di1j),"_"))[1],"_",
                                 if(length(unlist(strsplit(svalue(.di1j),"_")))==3)paste(unlist(strsplit(svalue(.di1j),"_"))[2],"_",unlist(strsplit(svalue(.di1j),"_"))[3],sep="") 
                                 else(unlist(strsplit(svalue(.di1j),"_"))[2]),"/", sep="")))
.ffotf[26,2]=(.plot_indivj=gdroplist(.models,container=.ffotf,expand=T))
addHandlerChanged(.di1j, handler=function(h,...) {
  .models=c("FOTF",list.files(paste(getwd(),"/Data/",svalue(.scen1j),"/",unlist(strsplit(svalue(.di1j),"_"))[1],"_",if(length(unlist(strsplit(svalue(.di1j),"_")))==3)paste(unlist(strsplit(svalue(.di1j),"_"))[2],"_",unlist(strsplit(svalue(.di1j),"_"))[3],sep="") else(unlist(strsplit(svalue(.di1j),"_"))[2]),"/", sep="")))
  .plot_indivj[]<-c(.models); svalue(.plot_indivj)<-"FOTF"
})
.ffotf[26,3]=gbutton(text="Plot",container=.ffotf,handler = function(.k,...){gplot_indiv_resultj() } )

##Space
.ffotf[27,1:3]=glabel("")

##zoom to area
.ffotf[28,1]=glabel("From map (zoom level)",container=.ffotf,cont=.k)
if(!svalue(.shpj)=="Select a shapefile..."){
  .sh=gsub("'","",svalue(.shpj))
  .sh1=shapefile(.sh)
  .ffotf[28,2]=(.areaj=gdroplist(if(colnames(head(.sh1))[1]=="GADMID"||colnames(head(.sh1))[1]=="ID_0"){
    c("No zoom","State","District")
  }else{
    if(colnames(head(.sh1))[5]=="ADM0_CODE"){
      c("No zoom","Country")
    } 
  },selected=1,container=.ffotf,expand=T))
}else{
  .ffotf[28,2]=(.areaj=gdroplist("No zoom",selected=1,container=.ffotf,expand=T))
}


addHandlerChanged(.shpj, handler=function(h,...) {
  .sh=gsub("'","",svalue(.shpj))
  .sh1=shapefile(.sh)  
  if(colnames(head(.sh1))[1]=="GADMID"||colnames(head(.sh1))[1]=="ID_0"){
    .areaj[]<-c("No zoom","State","District")
    svalue(.areaj)<-"No zoom"
  }else{
    if(colnames(head(.sh1))[5]=="ADM0_CODE"){
      .areaj[]<-c("No zoom","Country")
      svalue(.areaj)<-"No zoom"
    }else{
    .areaj[]<-"No zoom"
    svalue(.areaj)<-"No zoom"
  }}
})


##Select analogue
.ffotf[30,2]=(.selj1=gbutton(text="GO",container=.ffotf,handler = function(.k,...){gsel_analoguej() }))

##Space
.ffotf[32,1:3]=glabel("")

##Analogue by coordinates
.ffotf[34,1]=glabel("From coordinates (dd)",container=.ffotf,cont=.k)
.ffotf[34,2]=(.lat_abc_j=gedit(initial.msg="lat."))
.ffotf[36,2]=(.long_abc_j=gedit(initial.msg="long."))
.ffotf[38,2]=(.selj2=gbutton(text="GO",container=.ffotf,handler = function(.k,...){ganalogue_by_coords_j() } ))

.ffotf[40,1:3]=glabel("")

#.ffotf[42,2]=gbutton(text="Clear all graphs",container=.ffotf,handler = function(.k,...){graphics.off()} )


#---------------------------------------------------------------------
# Soils
#---------------------------------------------------------------------
.soil=glayout(homogeneous =F,cont=.nb,spacing=1,label=" C Soil data") 

#names(.last_run)
.soil[1,1]=glabel("FIll from reference site",container=.soil,cont=.k)
.soil[1,2]=gbutton(text="FIll",container=.soil,handler = function(.k,...){gfill_ref() } )
.soil[1,3]=(.soil_thresh=gedit(text=0.20))


.soil[2,1]=glabel("FIll from defaults",container=.soil,cont=.k)
.soil[2,2]=gbutton(text="FIll",container=.soil,handler = function(.k,...){gfill_man() } )






## status bar
.sb = gstatusbar("Select the '1A Basic run' or '2A FOTF run' tab to enter parameters and begin searching for climate analogues.", container=.win)
enabled(.seli1)=F
enabled(.seli2)=F
enabled(.selj1)=F
enabled(.selj2)=F
enabled(.bbr)=F
enabled(.ffotf)=F
enabled(.soil)=F
svalue(.nb)<-1
visible(.win) = T
focus(.win)
