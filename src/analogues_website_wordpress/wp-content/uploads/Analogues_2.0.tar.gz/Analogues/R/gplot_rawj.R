gplot_rawj <-
function(){
  enabled(.win)=F
  svalue(.sb)="Plotting raw climatic similarity results from the slected GCMs..."
  models=list.files(paste(getwd(),"/Data/",svalue(.scen1j),"/",unlist(strsplit(svalue(.di1j),"_"))[1],"_",if(length(unlist(strsplit(svalue(.di1j),"_")))==3)paste(unlist(strsplit(svalue(.di1j),"_"))[2],"_",unlist(strsplit(svalue(.di1j),"_"))[3],sep="") else(unlist(strsplit(svalue(.di1j),"_"))[2]),"/", sep=""))
  all_gcms=paste(getwd(),"/Results/",svalue(.sitej),"_FOTF/Individual_GCMs/",models,".tif",sep="")
  all_gcms=lapply(all_gcms,FUN=raster)
  all_gcms=stack(all_gcms)
  #x11()
  print(spplot(all_gcms,col.regions=colorRampPalette(c('red','yellow','green'))(16), main=paste("FOTF run- raw climatic similarity results, ",svalue(.sitej),sep=""),maxpixels=10000))
  enabled(.win)=T
  svalue(.sb)="Finished. See produced plot."
}
