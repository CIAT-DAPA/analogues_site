calc_similarity<-
  function(params)
  {
    infotile = zones[which(row.names(zones) == paste(params$zones[1], "_", params$resolution[1], sep = "")), ]
    total_tiles = (infotile$NCOLS_TILES * infotile$NROWS_TILES) - 1
    val_ref = ref_vals(params)
    wrapper = function(i) {
      training_targ = loadData_targ(params, i)
      if (params$rotation == "none" ) {## | sum(!is.na(training_targ[[1]][, 1])) <= 100necessary??
        training_targ = training_targ
      } else {
        training_targ = rota_stack(val_ref, training_targ, params)
      }
      return(similarity(training_targ, val_ref, params))
    }
    infotile_2 = zones[which(row.names(zones) == paste(params$zones[2], "_", params$resolution[2], sep = "")), ]
    total_tiles_2 = (infotile_2$NCOLS_TILES * infotile_2$NROWS_TILES) - 1
    if (total_tiles_2 == 0){
      merged_tiles= wrapper(total_tiles_2)[[1]]
    }else{
      sfInit(parallel = T, cpus = if (total_tiles_2<=25){total_tiles_2 + 1}else{26})
      sfExport("params")
      sfExport("val_ref")
      sfExport("sim_index_table")
      sfLibrary(stringr)
      sfLibrary(raster)
      sfLibrary(Analogues)
      cat(paste("Calculating...\n"))
      res_tiles=sfLapply(0:total_tiles_2,fun = wrapper)
      sfStop()
      cat("Merging tiles...\n")
      if(length(res_tiles)>140){
        
        m1=res_tiles[1:100]           ; m1=do.call(merge,m1)
        m2=res_tiles[101:length(res_tiles)]; m2=do.call(merge,m2)
        merged_tiles=c(m1,m2)
        merged_tiles=do.call(merge,merged_tiles)
      }else{
        merged_tiles=do.call(merge,res_tiles)
      }
    }
    cat("Writing raster...\n")
    writeRaster(merged_tiles, paste(params$outfile, "/out.tif", sep = ""), overwrite = TRUE)
  }