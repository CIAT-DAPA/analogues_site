ggraph_refi <-
function (){
  params = createParameters(x=as.numeric(svalue(.longi)),
                            y=as.numeric(svalue(.lati)),
                            method="dummy",
                            direction="dummy",
                            period=c("1960_1990","dummy"),
                            scenario=c("baseline","dummy"),
                            model=c("current","dummy"),
                            vars=c("prec","tmean"),
                            weights=c("dummy","dummy"),
                            ndivisions=c(12,12),
                            growing.season=c("dummy"),
                            rotation="dummy",
                            zones=c(unlist(strsplit(svalue(.di1i),"_"))[1],"dummy"),
                            resolution=c(if(length(unlist(strsplit(svalue(.di1i),"_")))==3)paste(unlist(strsplit(svalue(.di1i),"_"))[2],"_",unlist(strsplit(svalue(.di1i),"_"))[3],sep="") else(unlist(strsplit(svalue(.di1i),"_"))[2]),"dummy"),
                            env.data=paste(getwd(),"/Data",sep=""),
                            outfile="dummy",
                            ext=".tif",
                            threshold="dummy")
  
  ##Ref vals for reference site current
  data_ref_current=ref_vals(params)
  
  ##Ref vals for reference site future
  if (svalue(.direci)=="backwards"){
    scen=svalue(.scen1i)
    mod=svalue(.model1i)
    yr=svalue(.p1i)
  } else {
    if(svalue(.direci)=="forwards"){
      scen=svalue(.scen2i)
      mod=svalue(.model2i)
      yr=svalue(.p2i)
    } else {
      scen=list.files(paste(getwd(),"/Data",sep=""))[-which(list.files(paste(getwd(),"/Data",sep=""))=="baseline")][1]
      mod="ensemble"
      yr=list.files(paste(getwd(),"/Data/",scen,"/",svalue(.di1i),"/",mod,sep=""))[1]
    }
  }
  params$scenario[1]=scen
  params$period[1]=yr
  params$model[1]=mod
  data_ref_ensemble=ref_vals(params)
  
  ##prec table
  prec_data_basic_ref=rbind.data.frame(data_ref_current[[1]],data_ref_ensemble[[1]])
  colnames(prec_data_basic_ref)=c(month.abb)
  rownames(prec_data_basic_ref)=c("ref_current",paste("ref_",params$model[1],sep=""))
  Annual_total=rowSums(prec_data_basic_ref)
  print("Reference site precipitation")
  prec_data_basic_ref=print(cbind(prec_data_basic_ref,Annual_total))
  
  ##Prec Graph
  prec_data=t(prec_data_basic_ref[1:2,1:12])
  #x11()
  matplot(prec_data[,],type="l",col="gray",lty=1,ylab="Precipitation (mm)",
          xlab="",main=paste("Current and future projected precipitation - ",svalue(.sitei),sep=""), xaxt="n")
  axis(1, at=1:12, labels=month.name,cex.axis=0.8,las=2)
  lines(prec_data[,paste("ref_",params$model[1],sep="")],type="l",col="red",lwd=2)
  lines(prec_data[,'ref_current'],type="l",col="blue",lwd=2)
  legend(10,max(prec_data),c("current",params$model[1]),pt.bg="transparent",box.col="transparent",cex=0.9,col=c("blue","red"),lwd=c(2,2,1))
  grid()
  
  ##table
  tmean_data_basic_ref=rbind.data.frame(data_ref_current[[2]],data_ref_ensemble[[2]])
  tmean_data_basic_ref=tmean_data_basic_ref/10
  colnames(tmean_data_basic_ref)=c(month.abb)
  rownames(tmean_data_basic_ref)=c("ref_current",paste("ref_",params$model[1],sep=""))
  Average=rowMeans(tmean_data_basic_ref)
  options(digits=3)
  print("Reference site mean temperature")
  tmean_data_basic_ref=print(cbind(tmean_data_basic_ref,Average))
  
  ##Tmean Graph
  tmean_data=t(tmean_data_basic_ref[1:2,1:12])
  matplot(tmean_data[,],type="l",col="gray",lty=1,ylab="Mean temperature (degrees Celsius)",
          xlab="",main=paste("Current and future projected mean temperatures - ",svalue(.sitei),sep=""), xaxt="n")
  axis(1, at=1:12, labels=month.name,cex.axis=0.8,las=2)
  lines(tmean_data[,paste("ref_",params$model[1],sep="")],type="l",col="red",lwd=2)
  lines(tmean_data[,'ref_current'],type="l",col="blue",lwd=2)
  legend(10,max(tmean_data),c("current",params$model[1]),pt.bg="transparent",box.col="transparent",cex=0.9,col=c("blue","red"),lwd=c(2,2,1))
  grid()
  
  write.csv(tmean_data_basic_ref,paste(getwd(),"/Results/",svalue(.sitei),"_",svalue(.direci),"/","ref_basic_tmean",sep=""))
  write.csv( prec_data_basic_ref,paste(getwd(),"/Results/",svalue(.sitei),"_",svalue(.direci),"/", "ref_basic_prec",sep=""))
}
