loadData_targ <-
function (params, numtile) 
{
  training <- list()
  paths <- as.vector(t(outer(str_c(params$env.data, "/", params$scenario[2], 
                                   "/", paste(params$zones[2], "_", params$resolution[2], 
                                              sep = ""), "/", params$model[2], "/", params$period[2], 
                                   "/"), str_c(paste(as.character(lapply(1:length(params$vars), 
                                                                         function(x) strsplit(params$vars, "_")[[x]][1])), "_tif", 
                                                     sep = ""), "/", params$scenario[2], "_", params$period[2], 
                                               "_", params$model[2], "_", params$vars, "_"), FUN = "str_c")))
  training <- lapply(paths, function(x) loadGridsFromFiles(x, 
                                                           params, numtile, paths))
  return(training)
}
