Load_GUI <-
function(){
  source(paste(getwd(), "/R and Analogues install/Install for Windows/Read_only/R Scripts/Analogues_interface_loading.R",sep = ""))
}
