gplot_rawi <-
function(){
  enabled(.win)=F
  svalue(.sb)="Plotting raw results..."
  rs=raster(paste(getwd(),"/Results/",svalue(.sitei),"_",svalue(.direci),"/",svalue(.sitei),"_",svalue(.direci),".tif",sep=""))
  if(!(svalue(.shpi)=="Select a shapefile...")){
    .sh=gsub("'","",svalue(.shpi))
    .sh1=shapefile(.sh)
    plot_sh=function(){plot(.sh1,add=T)
    }
  }else{
    plot_sh=function(){}
  }
  #x11()
  plot(rs,main=paste("Climatic similarity- ",svalue(.sitei),"\n",
                     if(svalue(.direci)=="backwards"){
                       paste("backwards: ",svalue(.model1i),sep="") 
                     }else{
                       if(svalue(.direci)=="forwards"){
                         paste("forwards: ",svalue(.model2i),sep="") 
                       }else{
                         if(svalue(.model1i)==svalue(.model2i)){
                           paste("non-directional: ",svalue(.model1i),sep="") 
                         }else{
                           paste("non-directional: ",svalue(.model1i)," v ",svalue(.model2i),sep="") 
                         }
                       }
                     },sep=""))
  plot_sh()
  points(as.numeric(svalue(.longi)),as.numeric(svalue(.lati)),col="red",pch=16)
  svalue(.sb)="Finished. See produced plot."
  enabled(.win)=T
}
