gsel_analoguei <-
function(){
  enabled(.win)=F
  svalue(.sb)="Plotting results..."
  rs=.thresh_resi
  most_similar=rs>quantile(rs,as.numeric(svalue(.threshi)))
  rs=rs*most_similar
  rs1=rs
  labi=paste(as.numeric(svalue(.threshi))*100,"% threshold applied- ",svalue(.sitei),"\n",
             if(svalue(.direci)=="backwards"){
               paste("backwards: ",svalue(.model1i),sep="") 
             }else{
               if(svalue(.direci)=="forwards"){
                 paste("forwards: ",svalue(.model2i),sep="") 
               }else{
                 if(svalue(.model1i)==svalue(.model2i)){
                   paste("non-directional: ",svalue(.model1i),sep="") 
                 }else{
                   paste("non-directional: ",svalue(.model1i)," v ",svalue(.model2i),sep="") 
                 }
               }
             },sep="")
  if(!(svalue(.shpi)=="Select a shapefile...")){
    .sh=gsub("'","",svalue(.shpi))
    .sh1=shapefile(.sh)
    plot_sh=function(){plot(.sh1,add=T)
    }
  }else{
    plot_sh=function(){}
  }
  if(svalue(.areai)=="No zoom"){
    svalue(.sb)="Click on the map to select an analogue site to investigate."
    x11()
    plot(rs,main=paste(labi,"\nClick on the map to select an analogue site to investigate",sep=""))
    plot_sh()
    points(as.numeric(svalue(.longi)),as.numeric(svalue(.lati)),col="red",pch=16)
    print("Analogue site coordinates")
    analogue_site=click(rs,n=1,xy=TRUE)
    points(analogue_site$x,analogue_site$y,col="black",pch=16)
    Sys.sleep(1)
    dev.off()
    ###set coordinates to 3 dp
    long_r=format(round(as.numeric(svalue(.longi)),digits=3), nsmall = 3)
    lat_r=format(round(as.numeric(svalue(.lati)),digits=3), nsmall = 3)
    long_a=format(round(analogue_site$x,digits=3), nsmall = 3)
    lat_a=format(round(analogue_site$y,digits=3), nsmall = 3)
    plot(rs, main=paste(labi,"\nAnalogue site: Lat=",lat_a,", Long=",long_a,sep=""))
    plot_sh()
    points(as.numeric(svalue(.longi)),as.numeric(svalue(.lati)),col="red",pch=16)
    points(analogue_site$x,analogue_site$y,col="black",pch=16)
  } else{
    if(svalue(.areai)=="Country"){
      .sh1=shapefile(.sh)
      .sh0=.sh1
      x11()
      plot(rs,main=paste(labi,"\n Click on the map to zoom to country of interest.",sep=""))
      plot_sh()
      points(as.numeric(svalue(.longi)),as.numeric(svalue(.lati)),col="red",pch=16)
      svalue(.sb)="Click on the map to zoom to country of interest"
      print("Analogue site coordinates")
      region=click(.sh1,n=1)
      .sh1=.sh1[which(.sh1$ADM0_NAME==region$ADM0_NAME),]
      plot(.sh1,lwd=2,add=T)
      rs=crop(rs,.sh1)
      rs=mask(rs,.sh1)
      plot(rs,main=paste(labi," within ",region$ADM0_NAME,"\nClick on the map to select an analogue site to investigate",sep=""))
      svalue(.sb)="Click on the map to select an analogue site to investigate."
      plot(.sh1,add=T, lwd = 2)
      points(as.numeric(svalue(.longi)),as.numeric(svalue(.lati)),col="red",pch=16)
      analogue_site=click(rs,n=1,xy=TRUE)
      points(analogue_site$x,analogue_site$y,col="black",pch=16)
      Sys.sleep(1)
      dev.off()
      ###set coordinates to 3 dp
      long_r=format(round(as.numeric(svalue(.longi)),digits=3), nsmall = 3)
      lat_r=format(round(as.numeric(svalue(.lati)),digits=3), nsmall = 3)
      long_a=format(round(analogue_site$x,digits=3), nsmall = 3)
      lat_a=format(round(analogue_site$y,digits=3), nsmall = 3)
      
      plot(rs1, main=paste(labi," within ",region$ADM0_NAME,
                           "\nAnalogue site: Lat=",lat_a,", Long=",long_a,sep=""))
      plot(.sh0,add=T)
      plot(.sh1,lwd=2,add=T)
      points(as.numeric(svalue(.longi)),as.numeric(svalue(.lati)),col="red",pch=16)
      points(analogue_site$x,analogue_site$y,col="black",pch=16)
      
      plot(rs, main=paste(labi," within ",region$ADM0_NAME,
                          "\nAnalogue site: Lat=",lat_a,", Long=",long_a,sep=""))
      plot(.sh1,lwd=2,add=T)
      points(as.numeric(svalue(.longi)),as.numeric(svalue(.lati)),col="red",pch=16)
      points(analogue_site$x,analogue_site$y,col="black",pch=16)
      }else {
    if((svalue(.areai)=="State")){
      .sh=gsub("0","1",.sh)
      .sh=gsub("2","1",.sh)
      .sh1=shapefile(.sh)
      .sh0=.sh1
      x11()
      plot(rs,main=paste(labi,"\n Click on the map to zoom to state of interest.",sep=""))
      plot_sh()
      points(as.numeric(svalue(.longi)),as.numeric(svalue(.lati)),col="red",pch=16)
      svalue(.sb)="Click on the map to zoom to state of interest"
      print("Analogue site coordinates")
      region=click(.sh1,n=1)
      .sh1=.sh1[which(.sh1$NAME_1==region$NAME_1),]
      plot(.sh1,lwd=2,add=T)
      rs=crop(rs,.sh1)
      rs=mask(rs,.sh1)
      plot(rs,main=paste(labi," within ",region$NAME_1,"\nClick on the map to select an analogue site to investigate",sep=""))
      svalue(.sb)="Click on the map to select an analogue site to investigate."
      plot(.sh1,add=T, lwd = 2)
      .sh2=gsub("1","2",.sh)
      .sh2=shapefile(.sh2)
      .sh2=.sh2[which(.sh2$NAME_1==region$NAME_1),]
      plot(.sh2,add=T)
      points(as.numeric(svalue(.longi)),as.numeric(svalue(.lati)),col="red",pch=16)
      analogue_site=click(rs,n=1,xy=TRUE)
      points(analogue_site$x,analogue_site$y,col="black",pch=16)
      Sys.sleep(1)
      dev.off()
      ###set coordinates to 3 dp
      long_r=format(round(as.numeric(svalue(.longi)),digits=3), nsmall = 3)
      lat_r=format(round(as.numeric(svalue(.lati)),digits=3), nsmall = 3)
      long_a=format(round(analogue_site$x,digits=3), nsmall = 3)
      lat_a=format(round(analogue_site$y,digits=3), nsmall = 3)
      
      plot(rs1, main=paste(labi," within ",region$NAME_1,
                          "\nAnalogue site: Lat=",lat_a,", Long=",long_a,sep=""))
      plot(.sh0,add=T)
      plot(.sh1,lwd=2,add=T)
      points(as.numeric(svalue(.longi)),as.numeric(svalue(.lati)),col="red",pch=16)
      points(analogue_site$x,analogue_site$y,col="black",pch=16)
      
      plot(rs, main=paste(labi," within ",region$NAME_1,
                          "\nAnalogue site: Lat=",lat_a,", Long=",long_a,sep=""))
      plot(.sh1,lwd=2,add=T)
      plot(.sh2,add=T)      
      points(as.numeric(svalue(.longi)),as.numeric(svalue(.lati)),col="red",pch=16)
      points(analogue_site$x,analogue_site$y,col="black",pch=16)
      
      #######################################################
    }else{if(svalue(.areai)=="District"){
      .sh=gsub("0","1",.sh)
      .sh=gsub("2","1",.sh)
      .sh1=shapefile(.sh)
      .sh0=.sh1
      x11()
      plot(rs,main=paste(labi,"\n Click on the map to zoom to state of interest.",sep=""))
      svalue(.sb)="Click on the map to zoom to state of interest"
      plot_sh()
      points(as.numeric(svalue(.longi)),as.numeric(svalue(.lati)),col="red",pch=16)
      region=click(.sh1,n=1)
      .sh1=.sh1[which(.sh1$NAME_1==region$NAME_1),]
      .sh00=.sh1
      plot(.sh1,lwd=2,add=T)
      rs=crop(rs,.sh1)
      rs=mask(rs,.sh1)
      rs2=rs
      plot(rs,main=paste(labi," within ",region$NAME_1,
                         "\n Click on the map to zoom to district of interest",sep=""))
      svalue(.sb)="Click on the map to zoom to district of interest."
      plot(.sh1,add=T, lwd = 2)
      .sh2=gsub("1","2",.sh)
      .sh2=shapefile(.sh2)
      .sh2=.sh2[which(.sh2$NAME_1==region$NAME_1),]
      plot(.sh2,add=T)
      points(as.numeric(svalue(.longi)),as.numeric(svalue(.lati)),col="red",pch=16)
      region=click(.sh2,n=1)
      .sh000=.sh2
      .sh2=.sh2[which(.sh2$NAME_2==region$NAME_2),]
      plot(.sh2,lwd=2,add=T)
      rs=crop(rs,.sh2)
      rs=mask(rs,.sh2)
      plot(rs,main=paste(labi," within ",region$NAME_2,"\nClick on the map to select an analogue site to investigate",sep=""))
      svalue(.sb)="Click on the map to select an analogue site to investigate."
      plot(.sh2,add=T)
      points(as.numeric(svalue(.longi)),as.numeric(svalue(.lati)),col="red",pch=16)
      analogue_site=click(rs,n=1,xy=TRUE)
      points(analogue_site$x,analogue_site$y,col="black",pch=16)
      Sys.sleep(1)
      dev.off()
      ###set coordinates to 3 dp
      long_r=format(round(as.numeric(svalue(.longi)),digits=3), nsmall = 3)
      lat_r=format(round(as.numeric(svalue(.lati)),digits=3), nsmall = 3)
      long_a=format(round(analogue_site$x,digits=3), nsmall = 3)
      lat_a=format(round(analogue_site$y,digits=3), nsmall = 3)
      
      plot(rs1, main=paste(labi, " within ",region$NAME_1,
                           "\nAnalogue site: Lat=",lat_a,", Long=",long_a,sep=""))
      plot(.sh0,add=T)
      plot(.sh1,lwd=2,add=T)
      points(as.numeric(svalue(.longi)),as.numeric(svalue(.lati)),col="red",pch=16)
      points(analogue_site$x,analogue_site$y,col="black",pch=16)
      
      plot(rs2, main=paste(labi," within ",region$NAME_2,
                         "\nAnalogue site: Lat=",lat_a,", Long=",long_a,sep=""))
      plot(.sh00,add=T)
      plot(.sh000,add=T)
      plot(.sh2,lwd=2,add=T)
      points(as.numeric(svalue(.longi)),as.numeric(svalue(.lati)),col="red",pch=16)
      points(analogue_site$x,analogue_site$y,col="black",pch=16)
      
      
      plot(rs, main=paste(labi," within ",region$NAME_2,
                          "\nAnalogue site: Lat=",lat_a,", Long=",long_a,sep=""))
      plot(.sh2,lwd=2,add=T)
      points(as.numeric(svalue(.longi)),as.numeric(svalue(.lati)),col="red",pch=16)
      points(analogue_site$x,analogue_site$y,col="black",pch=16)
    }}
    }
  }
  #####################################
  svalue(.sb)="Extracting data from the selected analogue site..."
  ##Params
  params = createParameters(x=as.numeric(svalue(.longi)),
                            y=as.numeric(svalue(.lati)),
                            method="dummy",
                            direction=svalue(.direci),
                            period=c("1960_1990","dummy"),
                            scenario=c("baseline","dummy"),
                            model=c("current","dummy"),
                            vars=c("prec","tmean"),
                            weights=c("dummy","dummy"),
                            ndivisions=c(12,12),
                            growing.season=c("dummy"),
                            rotation="dummy",
                            zones=c(unlist(strsplit(svalue(.di1i),"_"))[1],"dummy"),
                            resolution=c(if(length(unlist(strsplit(svalue(.di1i),"_")))==3)paste(unlist(strsplit(svalue(.di1i),"_"))[2],"_",unlist(strsplit(svalue(.di1i),"_"))[3],sep="") else(unlist(strsplit(svalue(.di1i),"_"))[2]),"dummy"),
                            env.data=paste(getwd(),"/Data",sep=""),
                            outfile="dummy",
                            ext=".tif",
                            threshold="dummy")
  
  ##Ref vals for analogue current
  params$x=analogue_site$x; params$y=analogue_site$y
  data_analogue_current=ref_vals(params)
  
  ##Ref vals for analogue future
  params$x=analogue_site$x; params$y=analogue_site$y
  if (svalue(.direci)=="backwards"){
    scen=svalue(.scen1i)
    mod=svalue(.model1i)
    yr=svalue(.p1i)
  } else {
    if(svalue(.direci)=="forwards"){
      scen=svalue(.scen2i)
      mod=svalue(.model2i)
      yr=svalue(.p2i)
    } else {
      scen=list.files(paste(getwd(),"/Data",sep=""))[-which(list.files(paste(getwd(),"/Data",sep=""))=="baseline")][1]
      mod="ensemble"
      yr=list.files(paste(getwd(),"/Data/",scen,"/",svalue(.di1i),"/",mod,sep=""))[1]
    }
  }
  params$scenario[1]=scen
  params$period[1]=yr
  params$model[1]=mod
  data_analogue_ensemble=ref_vals(params)
  
  
  ##Prec Table for ref site and analogue site
  prec_data_basic=read.csv(paste(getwd(),"/Results/",svalue(.sitei),"_",svalue(.direci),"/ref_basic_prec",sep=""),header=TRUE,row.names=1)
  prec_data_basic=rbind(prec_data_basic[1:2,1:12], data_analogue_current[[1]],data_analogue_ensemble[[1]])
  rownames(prec_data_basic)=c("ref_current",paste("ref_",params$model[1],sep=""),"analogue_current",paste("analogue_",params$model[1],sep=""))
  Annual_total=rowSums(prec_data_basic)
  Lat.=rbind(lat_r,lat_r,lat_a,lat_a)
  Long.=rbind(long_r,long_r,long_a,long_a)
  print("Reference and analogue site precipitation")
  prec_data_basic=print(cbind(prec_data_basic,Annual_total,Lat.,Long.))
  prec_data=t(prec_data_basic[,1:12])
  
  ##Tmean Table for ref site and analogue site
  tmean_data_basic=read.csv(paste(getwd(),"/Results/",svalue(.sitei),"_",svalue(.direci),"/ref_basic_tmean",sep=""),header=TRUE,row.names=1)
  tmean_data_basic=rbind(tmean_data_basic[1:2,1:12], data_analogue_current[[2]]/10,data_analogue_ensemble[[2]]/10)
  rownames(tmean_data_basic)=c("ref_current",paste("ref_",params$model[1],sep=""),"analogue_current",paste("analogue_",params$model[1],sep=""))
  Average=rowMeans(tmean_data_basic)
  Lat.=rbind(lat_r,lat_r,lat_a,lat_a)
  Long.=rbind(long_r,long_r,long_a,long_a)
  print("Reference and analogue site mean temperature")
  tmean_data_basic=print(cbind(tmean_data_basic,Average,Lat.,Long.))
  tmean_data=t(tmean_data_basic[,1:12]) 
  
  ##Prec Graph for ref site and analogue site
  #x11()
  if (svalue(.direci)=="backwards"){
    matplot(prec_data[,],type="l",col="white",lty=1,ylab="Precipitation (mm)",
            xlab="",main=paste("Backwards analysis precipitation- ",svalue(.sitei),"\nAnalogue site: Lat=",lat_a,", Long=",long_a,sep=""), xaxt="n")
    axis(1, at=1:12, labels=month.name,cex.axis=0.8,las=2)
    lines(prec_data[,paste("ref_",params$model[1],sep="")],type="l",col="red",lwd=2)
    lines(prec_data[,'ref_current'],type="l",col="blue",lwd=2)
    lines(prec_data[,'analogue_current'],type="l",col="black",lwd=2)
    legend(9,max(prec_data),c("ref_current",paste("ref_",params$model[1],sep=""),"analogue_current"),pt.bg="transparent",box.col="transparent",cex=0.9,col=c("blue","red","black"),lwd=c(2,2,1))
    grid()
  }
  
  if(svalue(.direci)=="forwards"){
    matplot(prec_data[,],type="l",col="white",lty=1,ylab="Precipitation (mm)",
            xlab="",main=paste("Forwards analysis precipitation - ",svalue(.sitei),"\nAnalogue site: Lat=",lat_a,", Long=",long_a,sep=""), xaxt="n")
    axis(1, at=1:12, labels=month.name,cex.axis=0.8,las=2)
    lines(prec_data[,'ref_current'],type="l",col="blue",lwd=2)
    lines(prec_data[,paste("analogue_",params$model[1],sep="")],type="l",col="black",lwd=2)
    lines(prec_data[,'analogue_current'],type="l",col="grey",lwd=2)
    legend(9,max(prec_data),c("ref_current","analogue_current",paste("analogue_",params$model[1],sep="")),pt.bg="transparent",box.col="transparent",cex=0.9,col=c("blue","grey","black"),lwd=c(2,2,1))
    grid()
  }
  
  if(svalue(.direci)=="none"){
    matplot(prec_data[,],type="l",col="white",lty=1,ylab="Precipitation (mm)",
            xlab="",main=paste("None-directional analysis precipitation - ",svalue(.sitei),"\nAnalogue site: Lat=",lat_a,", Long=",long_a,sep=""), xaxt="n")
    axis(1, at=1:12, labels=month.name,cex.axis=0.8,las=2)
    lines(prec_data[,paste("ref_",params$model[1],sep="")],type="l",col="red",lwd=2)
    lines(prec_data[,'ref_current'],type="l",col="blue",lwd=2)
    lines(prec_data[,paste("analogue_",params$model[1],sep="")],type="l",col="black",lwd=2)
    lines(prec_data[,'analogue_current'],type="l",col="grey",lwd=2)
    legend(9,max(prec_data),c("ref_current",paste("ref_",params$model[1],sep=""),"analogue_current",paste("analogue_",params$model[1],sep="")),pt.bg="transparent",box.col="transparent",cex=0.9,col=c("blue","red","grey","black"),lwd=c(2,2,1))
    grid()
  }
  
  ##Tmean Graph for ref site and analogue site
  #x11()
  if (svalue(.direci)=="backwards"){
    matplot(tmean_data[,],type="l",col="white",lty=1,ylab="Mean temperature (degrees Celsius)",
            xlab="",main=paste("Backwards analysis temperature- ",svalue(.sitei),"\nAnalogue site: Lat=",lat_a,", Long=",long_a,sep=""), xaxt="n")
    axis(1, at=1:12, labels=month.name,cex.axis=0.8,las=2)
    lines(tmean_data[,paste("ref_",params$model[1],sep="")],type="l",col="red",lwd=2)
    lines(tmean_data[,'ref_current'],type="l",col="blue",lwd=2)
    lines(tmean_data[,'analogue_current'],type="l",col="black",lwd=2)
    legend(9,max(tmean_data),c("ref_current",paste("ref_",params$model[1],sep=""),"analogue_current"),pt.bg="transparent",box.col="transparent",cex=0.9,col=c("blue","red","black"),lwd=c(2,2,1))
    grid()
  }
  
  if(svalue(.direci)=="forwards"){
    matplot(tmean_data[,],type="l",col="white",lty=1,ylab="Mean temperature (degrees Celsius)",
            xlab="",main=paste("Forwards analysis temperature- ",svalue(.sitei),"\nAnalogue site: Lat=",lat_a,", Long=",long_a,sep=""), xaxt="n")
    axis(1, at=1:12, labels=month.name,cex.axis=0.8,las=2)
    lines(tmean_data[,'ref_current'],type="l",col="blue",lwd=2)
    lines(tmean_data[,paste("analogue_",params$model[1],sep="")],type="l",col="black",lwd=2)
    lines(tmean_data[,'analogue_current'],type="l",col="grey",lwd=2)
    legend(9,max(tmean_data),c("ref_current","analogue_current",paste("analogue_",params$model[1],sep="")),pt.bg="transparent",box.col="transparent",cex=0.9,col=c("blue","grey","black"),lwd=c(2,2,1))
    grid()
  }
  
  if(svalue(.direci)=="none"){
    matplot(tmean_data[,],type="l",col="white",lty=1,ylab="Mean temperature (degrees Celsius)",
            xlab="",main=paste("Non-directional analysis temperature- ",svalue(.sitei),"\nAnalogue site: Lat=",lat_a,", Long=",long_a,sep=""), xaxt="n")
    axis(1, at=1:12, labels=month.name,cex.axis=0.8,las=2)
    lines(tmean_data[,paste("ref_",params$model[1],sep="")],type="l",col="red",lwd=2)
    lines(tmean_data[,'ref_current'],type="l",col="blue",lwd=2)
    lines(tmean_data[,paste("analogue_",params$model[1],sep="")],type="l",col="black",lwd=2)
    lines(tmean_data[,'analogue_current'],type="l",col="grey",lwd=2)
    legend(9,max(tmean_data),c("ref_current",paste("ref_",params$model[1],sep=""),"analogue_current",paste("analogue_",params$model[1],sep="")),pt.bg="transparent",box.col="transparent",cex=0.9,col=c("blue","red","grey","black"),lwd=c(2,2,1))
    grid()
  }
  svalue(.sb)="Finished. See the produced graphs to compare prec and tmean values of the reference site and selected analogue."
  enabled(.win)=T
}
