gsel_analoguej <-
  function(){
    enabled(.win)=F
    svalue(.sb)="Plotting results..."
    if(svalue(.plot_indivj)=="FOTF"){
      rs=.thresh_resi
      labj=paste("FOTF analysis for ",svalue(.sitej),sep="")
    }else{
      rs=raster(paste(getwd(),"/Results/",svalue(.sitej),"_FOTF/Individual_GCMs/",svalue(.plot_indivj),".tif",sep=""))
      rs=rs>quantile(rs,as.numeric(svalue(.threshj)))
      labj=paste("Backwards analysis (",svalue(.plot_indivj),") ",svalue(.sitej),sep="")
    }
    if(!(svalue(.shpj)=="Select a shapefile...")){
      .sh=gsub("'","",svalue(.shpj))
      .sh1=shapefile(.sh)
      plot_sh=function(){plot(.sh1,add=T)
      }
    }else{
      plot_sh=function(){}
    }
    rs1=rs
    if(svalue(.areaj)=="No zoom"){
      svalue(.sb)="Click on the map to select an analogue site to investigate."
      x11()
      plot(rs,main=paste(labj,"\nClick on the map to select an analogue site to investigate",sep=""))
      plot_sh()
      points(as.numeric(svalue(.longj)),as.numeric(svalue(.latj)),col="red",pch=16)
      print("Analogue site coordinates")
      analogue_site=click(rs,n=1,xy=TRUE)
      points(analogue_site$x,analogue_site$y,col="black",pch=16)
      Sys.sleep(1)
      dev.off()
      ###set coordinates to 3 dp
      long_r=format(round(as.numeric(svalue(.longj)),digits=3), nsmall = 3)
      lat_r=format(round(as.numeric(svalue(.latj)),digits=3), nsmall = 3)
      long_a=format(round(analogue_site$x,digits=3), nsmall = 3)
      lat_a=format(round(analogue_site$y,digits=3), nsmall = 3)
      points(analogue_site$x,analogue_site$y,col="black",pch=16)
      plot(rs, main=paste(labj,"\nAnalogue site: Lat=",lat_a,", Long=",long_a,sep=""))
      plot_sh()
      points(as.numeric(svalue(.longj)),as.numeric(svalue(.latj)),col="red",pch=16)
      points(analogue_site$x,analogue_site$y,col="black",pch=16)
    } else {
      if((svalue(.areaj)=="Country")){
        .sh1=shapefile(.sh)
        .sh0=.sh1
        x11()
        plot(rs,main=paste(labj,"\n Click on the map to zoom to country of interest",sep=""))
        plot_sh()
        points(as.numeric(svalue(.longj)),as.numeric(svalue(.latj)),col="red",pch=16)
        svalue(.sb)="Click on the map to zoom to country of interest."
        region=click(.sh1,n=1)
        print("Analogue site coordinates")
        .sh1=.sh1[which(.sh1$ADM0_NAME==region$ADM0_NAME),]
        plot(.sh1,lwd=2,add=T)
        rs=crop(rs,.sh1)
        rs=mask(rs,.sh1)
        plot(rs,main=paste(labj," within ",region$ADM0_NAME,"\nClick on the map to select an analogue site to investigate",sep=""))
        svalue(.sb)="Click on the map to select an analogue site to investigate."
        plot(.sh1,add=T, lwd = 2)
        points(as.numeric(svalue(.longj)),as.numeric(svalue(.latj)),col="red",pch=16)
        analogue_site=click(rs,n=1,xy=TRUE)
        points(analogue_site$x,analogue_site$y,col="black",pch=16)
        Sys.sleep(1)
        dev.off()
        ###set coordinates to 3 dp
        long_r=format(round(as.numeric(svalue(.longj)),digits=3), nsmall = 3)
        lat_r=format(round(as.numeric(svalue(.latj)),digits=3), nsmall = 3)
        long_a=format(round(analogue_site$x,digits=3), nsmall = 3)
        lat_a=format(round(analogue_site$y,digits=3), nsmall = 3)
        
        plot(rs1, main=paste(labj," within ",region$ADM0_NAME,
                             "\nAnalogue site: Lat=",lat_a,", Long=",long_a,sep=""))
        plot(.sh0,add=T)
        plot(.sh1,lwd=2,add=T)
        points(as.numeric(svalue(.longj)),as.numeric(svalue(.latj)),col="red",pch=16)
        points(analogue_site$x,analogue_site$y,col="black",pch=16)
        
        plot(rs, main=paste(labj," within ",region$ADM0_NAME,
                            "\nAnalogue site: Lat=",lat_a,", Long=",long_a,sep=""))
        plot(.sh1,lwd=2,add=T)
        points(as.numeric(svalue(.longj)),as.numeric(svalue(.latj)),col="red",pch=16)
        points(analogue_site$x,analogue_site$y,col="black",pch=16)
        
        #######################################################
      }else {
        if((svalue(.areaj)=="State")){
          .sh=gsub("0","1",.sh)
          .sh=gsub("2","1",.sh)
          .sh1=shapefile(.sh)
          .sh0=.sh1
          x11()
          plot(rs,main=paste(labj,"\n Click on the map to zoom to state of interest",sep=""))
          plot_sh()
          points(as.numeric(svalue(.longj)),as.numeric(svalue(.latj)),col="red",pch=16)
          svalue(.sb)="Click on the map to zoom to state of interest."
          print("Analogue site coordinates")
          region=click(.sh1,n=1)
          .sh1=.sh1[which(.sh1$NAME_1==region$NAME_1),]
          plot(.sh1,lwd=2,add=T)
          rs=crop(rs,.sh1)
          rs=mask(rs,.sh1)
          plot(rs,main=paste(labj," within ",region$NAME_1,"\nClick on the map to select an analogue site to investigate",sep=""))
          svalue(.sb)="Click on the map to select an analogue site to investigate."
          plot(.sh1,add=T, lwd = 2)
          .sh2=gsub("1","2",.sh)
          .sh2=shapefile(.sh2)
          .sh2=.sh2[which(.sh2$NAME_1==region$NAME_1),]
          plot(.sh2,add=T)
          points(as.numeric(svalue(.longj)),as.numeric(svalue(.latj)),col="red",pch=16)
          analogue_site=click(rs,n=1,xy=TRUE)
          points(analogue_site$x,analogue_site$y,col="black",pch=16)
          Sys.sleep(1)
          dev.off()
          ###set coordinates to 3 dp
          long_r=format(round(as.numeric(svalue(.longj)),digits=3), nsmall = 3)
          lat_r=format(round(as.numeric(svalue(.latj)),digits=3), nsmall = 3)
          long_a=format(round(analogue_site$x,digits=3), nsmall = 3)
          lat_a=format(round(analogue_site$y,digits=3), nsmall = 3)
          
          plot(rs1, main=paste(labj," within ",region$NAME_1,
                               "\nAnalogue site: Lat=",lat_a,", Long=",long_a,sep=""))
          plot(.sh0,add=T)
          plot(.sh1,lwd=2,add=T)
          points(as.numeric(svalue(.longj)),as.numeric(svalue(.latj)),col="red",pch=16)
          points(analogue_site$x,analogue_site$y,col="black",pch=16)
          
          plot(rs, main=paste(labj," within ",region$NAME_1,
                              "\nAnalogue site: Lat=",lat_a,", Long=",long_a,sep=""))
          plot(.sh1,lwd=2,add=T)
          plot(.sh2,add=T)
          points(as.numeric(svalue(.longj)),as.numeric(svalue(.latj)),col="red",pch=16)
          points(analogue_site$x,analogue_site$y,col="black",pch=16)
          
          #######################################################
        }else{if(svalue(.areaj)=="District"){
          .sh=gsub("0","1",.sh)
          .sh=gsub("2","1",.sh)
          .sh1=shapefile(.sh)
          .sh0=.sh1
          x11()
          plot(rs,main=paste(labj,"\n Click on the map to zoom to state of interest",sep=""))
          svalue(.sb)="Click on the map to zoom to state of interest."
          plot_sh()
          points(as.numeric(svalue(.longj)),as.numeric(svalue(.latj)),col="red",pch=16)
          region=click(.sh1,n=1)
          .sh1=.sh1[which(.sh1$NAME_1==region$NAME_1),]
          .sh00=.sh1
          plot(.sh1,lwd=2,add=T)
          rs=crop(rs,.sh1)
          rs=mask(rs,.sh1)
          rs2=rs
          plot(rs,main=paste(labj," within ",region$NAME_1,
                             "\n Click on the map to zoom to district of interest",sep=""))
          svalue(.sb)="Click on the map to zoom to district of interest."
          plot(.sh1,add=T, lwd = 2)
          .sh2=gsub("1","2",.sh)
          .sh2=shapefile(.sh2)
          .sh2=.sh2[which(.sh2$NAME_1==region$NAME_1),]
          plot(.sh2,add=T)
          points(as.numeric(svalue(.longj)),as.numeric(svalue(.latj)),col="red",pch=16)
          region=click(.sh2,n=1)
          .sh000=.sh2
          .sh2=.sh2[which(.sh2$NAME_2==region$NAME_2),]
          plot(.sh2,lwd=2,add=T)
          rs=crop(rs,.sh2)
          rs=mask(rs,.sh2)
          plot(rs,main=paste(labj," within ",region$NAME_1,"\nClick on the map to select an analogue site to investigate",sep=""))
          svalue(.sb)="Click on the map to select an analogue site to investigate."
          plot(.sh2,add=T)
          points(as.numeric(svalue(.longj)),as.numeric(svalue(.latj)),col="red",pch=16)
          analogue_site=click(rs,n=1,xy=TRUE)
          points(analogue_site$x,analogue_site$y,col="black",pch=16)
          Sys.sleep(1)
          dev.off()
          ###set coordinates to 3 dp
          long_r=format(round(as.numeric(svalue(.longj)),digits=3), nsmall = 3)
          lat_r=format(round(as.numeric(svalue(.latj)),digits=3), nsmall = 3)
          long_a=format(round(analogue_site$x,digits=3), nsmall = 3)
          lat_a=format(round(analogue_site$y,digits=3), nsmall = 3)
          
          plot(rs1, main=paste(labj, " within ",region$NAME_1,
                               "\nAnalogue site: Lat=",lat_a,", Long=",long_a,sep=""))
          plot(.sh0,add=T)
          plot(.sh1,lwd=2,add=T)
          points(as.numeric(svalue(.longj)),as.numeric(svalue(.latj)),col="red",pch=16)
          points(analogue_site$x,analogue_site$y,col="black",pch=16)
          
          plot(rs2, main=paste(labj," within ",region$NAME_2,
                               "\nAnalogue site: Lat=",lat_a,", Long=",long_a,sep=""))
          plot(.sh00,add=T)
          plot(.sh000,add=T)
          plot(.sh2,lwd=2,add=T)
          points(as.numeric(svalue(.longj)),as.numeric(svalue(.latj)),col="red",pch=16)
          points(analogue_site$x,analogue_site$y,col="black",pch=16)
          
          
          plot(rs, main=paste(labj," within ",region$NAME_2,
                              "\nAnalogue site: Lat=",lat_a,", Long=",long_a,sep=""))
          plot(.sh2,lwd=2,add=T)
          points(as.numeric(svalue(.longj)),as.numeric(svalue(.latj)),col="red",pch=16)
          points(analogue_site$x,analogue_site$y,col="black",pch=16)
        }
        }
      }
    }
    svalue(.sb)="Extracting data from the selected analogue site..."
    ## Loading current data at the analogue site
    params = createParameters(x=analogue_site$x,
                              y=analogue_site$y,
                              method="dummy",
                              direction="backwards",
                              period=c("1960_1990","dummy"),
                              scenario=c("baseline","dummy"),
                              model=c("current","dummy"),
                              vars=c("prec","tmean"),
                              weights=c("dummy","dummy"),
                              ndivisions=c(12,12),
                              growing.season=c("dummy"),
                              rotation="dummy",
                              zones=c(unlist(strsplit(svalue(.di1j),"_"))[1],"dummy"),
                              resolution=c(if(length(unlist(strsplit(svalue(.di1j),"_")))==3)paste(unlist(strsplit(svalue(.di1j),"_"))[2],"_",unlist(strsplit(svalue(.di1j),"_"))[3],sep="") else(unlist(strsplit(svalue(.di1j),"_"))[2]),"dummy"),
                              env.data=paste(getwd(),"/Data",sep=""),
                              outfile="dummy",
                              ext=".tif",
                              threshold="dummy")
    
    analogue_data=ref_vals(params)  
    
    ## Reference site GCMS and analogue site prec table
    prec_gcms=read.csv(paste(getwd(),"/Results/",svalue(.sitej),"_FOTF/FOTF_gcms_prec",sep=""),header=TRUE,row.names=1)
    prec_gcms=rbind(prec_gcms[,1:12],analogue_data[[1]])
    rownames(prec_gcms)=c(rownames(prec_gcms[1:(nrow(prec_gcms)-1),]),"analogue")
    Annual_total=rowSums(prec_gcms)
    print("GCM,current and analogue precipitation")
    print(cbind(prec_gcms,Annual_total))
    
    ## Reference site GCMS and analogue site tmean table
    tmean_gcms=read.csv(paste(getwd(),"/Results/",svalue(.sitej),"_FOTF/FOTF_gcms_tmean",sep=""),header=TRUE,row.names=1)
    tmean_gcms=rbind(tmean_gcms[,1:12],analogue_data[[2]]/10)
    rownames(tmean_gcms)=c(rownames(tmean_gcms[1:(nrow(tmean_gcms)-1),]),"analogue")
    Average=round(rowMeans(tmean_gcms),digits=1)
    print("GCM,current and analogue mean temperature")
    print(cbind(tmean_gcms,Average))
    
    ## Reference site GCMS and analogue site prec graph
    prec_data=t(prec_gcms[,1:12])
    #x11()
    matplot(prec_data[,],type="l",col="gray",lty=1,ylab="Precipitation (mm)",
            xlab="",main=paste(labj," analogue site comparison","\nAnalogue site: Lat=",lat_a,", Long=",long_a,sep=""), xaxt="n")
    axis(1, at=1:12, labels=month.name,cex.axis=0.8,las=2)
    lines(prec_data[,'ensemble'],type="l",col="red",lwd=2)
    lines(prec_data[,'current'],type="l",col="blue",lwd=2)
    lines(analogue_data[[1]],type="l",col="black",lwd=2)
    if(!svalue(.plot_indivj)=="FOTF"&&!svalue(.plot_indivj)=="ensemble"){lines(prec_data[,svalue(.plot_indivj)],type="l",col="green",lwd=2)}
    legend(10,max(prec_data),c("current","ensemble","All GCMs","analogue",if(!svalue(.plot_indivj)=="FOTF"&&!svalue(.plot_indivj)=="ensemble"){svalue(.plot_indivj)}),pt.bg="transparent",box.col="transparent",cex=0.9,col=c("blue","red","gray","black",if(!svalue(.plot_indivj)=="FOTF"&&!svalue(.plot_indivj)=="ensemble"){"green"}),lwd=c(2,2,1))
    grid()
    
    ## Reference site GCMS and analogue site tmean graph
    tmean_data=t(tmean_gcms[,1:12])
    #x11()
    matplot(tmean_data[,],type="l",col="gray",lty=1,ylab="Mean temperature (mm)",
            xlab="",main=paste(labj," analogue site comparison","\nAnalogue site: Lat=",lat_a,", Long=",long_a,sep=""), xaxt="n")
    axis(1, at=1:12, labels=month.name,cex.axis=0.8,las=2)
    lines(tmean_data[,'ensemble'],type="l",col="red",lwd=2)
    lines(tmean_data[,'current'],type="l",col="blue",lwd=2)
    lines(analogue_data[[2]]/10,type="l",col="black",lwd=2)
    if(!svalue(.plot_indivj)=="FOTF"&&!svalue(.plot_indivj)=="ensemble"){lines(tmean_data[,svalue(.plot_indivj)],type="l",col="green",lwd=2)}
    legend(10,max(tmean_data),c("current","ensemble","All GCMs","analogue",if(!svalue(.plot_indivj)=="FOTF"&&!svalue(.plot_indivj)=="ensemble"){svalue(.plot_indivj)}),pt.bg="transparent",box.col="transparent",cex=0.9,col=c("blue","red","gray","black",if(!svalue(.plot_indivj)=="FOTF"&&!svalue(.plot_indivj)=="ensemble"){"green"}),lwd=c(2,2,1))
    grid()
    
    ## Summary table for prec (current, ensemble, analogue)
    prec_analogue=rbind(prec_gcms['current',1:12], prec_gcms['ensemble',1:12],analogue_data[[1]])
    if(!svalue(.plot_indivj)=="FOTF"&&!svalue(.plot_indivj)=="ensemble"){prec_analogue=rbind(prec_analogue[1:2,],prec_gcms[svalue(.plot_indivj),1:12],prec_analogue=rbind(prec_analogue[3,]))}
    Annual_total=rowSums(prec_analogue)
    prec_analogue=cbind(prec_analogue,Annual_total)
    rownames(prec_analogue)=c("current","ensemble",if(!svalue(.plot_indivj)=="FOTF"&&!svalue(.plot_indivj)=="ensemble"){svalue(.plot_indivj)},"analogue")
    Lat.=c(lat_r,lat_r,if(!svalue(.plot_indivj)=="FOTF"&&!svalue(.plot_indivj)=="ensemble"){lat_r},lat_a)
    Long.=c(long_r,long_r,if(!svalue(.plot_indivj)=="FOTF"&&!svalue(.plot_indivj)=="ensemble"){long_r},long_a)
    prec_analogue=cbind(prec_analogue,Lat.,Long.)
    print("Summary table for precipitation")
    print(prec_analogue)
    
    ## Summary table for tmean (current, ensemble, analogue)
    tmean_analogue=rbind(tmean_gcms['current',1:12], tmean_gcms['ensemble',1:12],analogue_data[[2]]/10)
    if(!svalue(.plot_indivj)=="FOTF"&&!svalue(.plot_indivj)=="ensemble"){tmean_analogue=rbind(tmean_analogue[1:2,],tmean_gcms[svalue(.plot_indivj),1:12],tmean_analogue=rbind(tmean_analogue[3,]))}
    Average=round(rowMeans(tmean_analogue),digits=1)
    tmean_analogue=cbind(tmean_analogue,Average)
    rownames(tmean_analogue)=c("current","ensemble",if(!svalue(.plot_indivj)=="FOTF"&&!svalue(.plot_indivj)=="ensemble"){svalue(.plot_indivj)},"analogue")
    Lat.=c(lat_r,lat_r,if(!svalue(.plot_indivj)=="FOTF"&&!svalue(.plot_indivj)=="ensemble"){lat_r},lat_a)
    Long.=c(long_r,long_r,if(!svalue(.plot_indivj)=="FOTF"&&!svalue(.plot_indivj)=="ensemble"){long_r},long_a)
    tmean_analogue=cbind(tmean_analogue,Lat.,Long.)
    print("Summary table for mean temperature")
    print(tmean_analogue)
    enabled(.win)=T
    svalue(.sb)="Finished. See the produced graphs to compare prec and tmean values of the reference site and selected analogue."
  }
