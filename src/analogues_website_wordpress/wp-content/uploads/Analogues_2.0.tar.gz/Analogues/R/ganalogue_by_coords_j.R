ganalogue_by_coords_j <-
function(){
  enabled(.win)=F
  svalue(.sb)="Plotting results and selected analogue site..."
  long_r=format(round(as.numeric(svalue(.longj)),digits=3), nsmall = 3)
  lat_r=format(round(as.numeric(svalue(.latj)),digits=3), nsmall = 3)
  long_a=format(round(as.numeric(svalue(.long_abc_j)),digits=3), nsmall = 3)
  lat_a=format(round(as.numeric(svalue(.lat_abc_j)),digits=3), nsmall = 3)
  if(svalue(.plot_indivj)=="FOTF"){
    rs=.thresh_resi
    labj=paste("FOTF analysis for ",svalue(.sitej),sep="")
  }else{
    rs=raster(paste(getwd(),"/Results/",svalue(.sitej),"_FOTF/Individual_GCMs/",svalue(.plot_indivj),".tif",sep=""))
    rs=rs>quantile(rs,as.numeric(svalue(.threshj)))
    labj=paste("Backwards analysis (",svalue(.plot_indivj),") ",svalue(.sitej),sep="")
  }
  if(!(svalue(.shpj)=="Select a shapefile...")){
    .sh=gsub("'","",svalue(.shpj))
    .sh1=shapefile(.sh)
    plot_sh=function(){plot(.sh1,add=T)
    }
  }else{
    plot_sh=function(){}
  }
  ##Plotting
    #x11()
    plot(rs, main=paste(labj,"\nAnalogue site: Lat=",lat_a,", Long=",long_a,sep=""))
    plot_sh()
    points(long_r,lat_r,col="red",pch=16)
    points(long_a,lat_a,col="black",pch=16)
  
  
  svalue(.sb)="Extracting data from the selected analogue site..."
  ## Loading current data at the analogue site
  params = createParameters(x=as.numeric(long_a),
                            y=as.numeric(lat_a),
                            method="dummy",
                            direction="backwards",
                            period=c("1960_1990","dummy"),
                            scenario=c("baseline","dummy"),
                            model=c("current","dummy"),
                            vars=c("prec","tmean"),
                            weights=c("dummy","dummy"),
                            ndivisions=c(12,12),
                            growing.season=c("dummy"),
                            rotation="dummy",
                            zones=c(unlist(strsplit(svalue(.di1j),"_"))[1],"dummy"),
                            resolution=c(if(length(unlist(strsplit(svalue(.di1j),"_")))==3)paste(unlist(strsplit(svalue(.di1j),"_"))[2],"_",unlist(strsplit(svalue(.di1j),"_"))[3],sep="") else(unlist(strsplit(svalue(.di1j),"_"))[2]),"dummy"),
                            env.data=paste(getwd(),"/Data",sep=""),
                            outfile="dummy",
                            ext=".tif",
                            threshold="dummy")
  
  analogue_data=ref_vals(params)  
  
  ## Reference site GCMS and analogue site prec table
  prec_gcms=read.csv(paste(getwd(),"/Results/",svalue(.sitej),"_FOTF/FOTF_gcms_prec",sep=""),header=TRUE,row.names=1)
  prec_gcms=rbind(prec_gcms[,1:12],analogue_data[[1]])
  rownames(prec_gcms)=c(rownames(prec_gcms[1:(nrow(prec_gcms)-1),]),"analogue")
  Annual_total=rowSums(prec_gcms)
  print("GCM,current and analogue precipitation")
  print(cbind(prec_gcms,Annual_total))
  
  ## Reference site GCMS and analogue site tmean table
  tmean_gcms=read.csv(paste(getwd(),"/Results/",svalue(.sitej),"_FOTF/FOTF_gcms_tmean",sep=""),header=TRUE,row.names=1)
  tmean_gcms=rbind(tmean_gcms[,1:12],analogue_data[[2]]/10)
  rownames(tmean_gcms)=c(rownames(tmean_gcms[1:(nrow(tmean_gcms)-1),]),"analogue")
  Average=round(rowMeans(tmean_gcms),digits=1)
  print("GCM,current and analogue mean temperature")
  print(cbind(tmean_gcms,Average))
  
  ## Reference site GCMS and analogue site prec graph
  prec_data=t(prec_gcms[,1:12])
  #x11()
  matplot(prec_data[,],type="l",col="gray",lty=1,ylab="Precipitation (mm)",
          xlab="",main=paste(labj," analogue site comparison","\nAnalogue site: Lat=",lat_a,", Long=",long_a,sep=""), xaxt="n")
  axis(1, at=1:12, labels=month.name,cex.axis=0.8,las=2)
  lines(prec_data[,'ensemble'],type="l",col="red",lwd=2)
  lines(prec_data[,'current'],type="l",col="blue",lwd=2)
  lines(analogue_data[[1]],type="l",col="black",lwd=2)
  if(!svalue(.plot_indivj)=="FOTF"&&!svalue(.plot_indivj)=="ensemble"){lines(prec_data[,svalue(.plot_indivj)],type="l",col="green",lwd=2)}
  legend(10,max(prec_data),c("current","ensemble","All GCMs","analogue",if(!svalue(.plot_indivj)=="FOTF"&&!svalue(.plot_indivj)=="ensemble"){svalue(.plot_indivj)}),pt.bg="transparent",box.col="transparent",cex=0.9,col=c("blue","red","gray","black",if(!svalue(.plot_indivj)=="FOTF"&&!svalue(.plot_indivj)=="ensemble"){"green"}),lwd=c(2,2,1))
  grid()
  
  ## Reference site GCMS and analogue site tmean graph
  tmean_data=t(tmean_gcms[,1:12])
  #x11()
  matplot(tmean_data[,],type="l",col="gray",lty=1,ylab="Mean temperature (mm)",
          xlab="",main=paste(labj," analogue site comparison","\nAnalogue site: Lat=",lat_a,", Long=",long_a,sep=""), xaxt="n")
  axis(1, at=1:12, labels=month.name,cex.axis=0.8,las=2)
  lines(tmean_data[,'ensemble'],type="l",col="red",lwd=2)
  lines(tmean_data[,'current'],type="l",col="blue",lwd=2)
  lines(analogue_data[[2]]/10,type="l",col="black",lwd=2)
  if(!svalue(.plot_indivj)=="FOTF"&&!svalue(.plot_indivj)=="ensemble"){lines(tmean_data[,svalue(.plot_indivj)],type="l",col="green",lwd=2)}
  legend(10,max(tmean_data),c("current","ensemble","All GCMs","analogue",if(!svalue(.plot_indivj)=="FOTF"&&!svalue(.plot_indivj)=="ensemble"){svalue(.plot_indivj)}),pt.bg="transparent",box.col="transparent",cex=0.9,col=c("blue","red","gray","black",if(!svalue(.plot_indivj)=="FOTF"&&!svalue(.plot_indivj)=="ensemble"){"green"}),lwd=c(2,2,1))
  grid()
  
  ## Summary table for prec (current, ensemble, analogue)
  prec_analogue=rbind(prec_gcms['current',1:12], prec_gcms['ensemble',1:12],analogue_data[[1]])
  if(!svalue(.plot_indivj)=="FOTF"&&!svalue(.plot_indivj)=="ensemble"){prec_analogue=rbind(prec_analogue[1:2,],prec_gcms[svalue(.plot_indivj),1:12],prec_analogue=rbind(prec_analogue[3,]))}
  Annual_total=rowSums(prec_analogue)
  prec_analogue=cbind(prec_analogue,Annual_total)
  rownames(prec_analogue)=c("current","ensemble",if(!svalue(.plot_indivj)=="FOTF"&&!svalue(.plot_indivj)=="ensemble"){svalue(.plot_indivj)},"analogue")
  Lat.=c(lat_r,lat_r,if(!svalue(.plot_indivj)=="FOTF"&&!svalue(.plot_indivj)=="ensemble"){lat_r},long_a)
  Long.=c(long_r,long_r,if(!svalue(.plot_indivj)=="FOTF"&&!svalue(.plot_indivj)=="ensemble"){long_r},lat_a)
  prec_analogue=cbind(prec_analogue,Lat.,Long.)
  print("Summary table for precipitation")
  print(prec_analogue)
  
  ## Summary table for tmean (current, ensemble, analogue)
  tmean_analogue=rbind(tmean_gcms['current',1:12], tmean_gcms['ensemble',1:12],analogue_data[[2]]/10)
  if(!svalue(.plot_indivj)=="FOTF"&&!svalue(.plot_indivj)=="ensemble"){tmean_analogue=rbind(tmean_analogue[1:2,],tmean_gcms[svalue(.plot_indivj),1:12],tmean_analogue=rbind(tmean_analogue[3,]))}
  Average=round(rowMeans(tmean_analogue),digits=1)
  tmean_analogue=cbind(tmean_analogue,Average)
  rownames(tmean_analogue)=c("current","ensemble",if(!svalue(.plot_indivj)=="FOTF"&&!svalue(.plot_indivj)=="ensemble"){svalue(.plot_indivj)},"analogue")
  Lat.=c(lat_r,lat_r,if(!svalue(.plot_indivj)=="FOTF"&&!svalue(.plot_indivj)=="ensemble"){lat_r},long_a)
  Long.=c(long_r,long_r,if(!svalue(.plot_indivj)=="FOTF"&&!svalue(.plot_indivj)=="ensemble"){long_r},lat_a)
  tmean_analogue=cbind(tmean_analogue,Lat.,Long.)
  print("Summary table for mean temperature")
  print(tmean_analogue)
  enabled(.win)=T
  svalue(.sb)="Finished. See the produced graphs to compare prec and tmean values of the reference site and selected analogue."
}
