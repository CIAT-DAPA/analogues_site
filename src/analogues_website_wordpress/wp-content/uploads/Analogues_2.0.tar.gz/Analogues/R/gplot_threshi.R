gplot_threshi <-
function(){
  enabled(.win)=F
  svalue(.sb)="Applying threshold..."
  rs=.raw_resi
  if(!(svalue(.shpi)=="Select a shapefile...")){
    .sh=gsub("'","",svalue(.shpi))
    .sh1=shapefile(.sh)
    plot_sh=function(){plot(.sh1,add=T)
    }
  }else{
    plot_sh=function(){}
  }
  most_similar=rs>quantile(rs,as.numeric(svalue(.threshi)))
  #x11()
  most_similar=rs*most_similar
  plot(most_similar,main=paste(as.numeric(svalue(.threshi))*100,"% threshold applied- ",svalue(.sitei),"\n",
                               if(svalue(.direci)=="backwards"){
                                 paste("backwards: ",svalue(.model1i),sep="") 
                               }else{
                                 if(svalue(.direci)=="forwards"){
                                   paste("forwards: ",svalue(.model2i),sep="") 
                                 }else{
                                   if(svalue(.model1i)==svalue(.model2i)){
                                     paste("non-directional: ",svalue(.model1i),sep="") 
                                   }else{
                                     paste("non-directional: ",svalue(.model1i)," v ",svalue(.model2i),sep="") 
                                   }
                                 }
                               },sep=""))
  plot_sh()
  points(as.numeric(svalue(.longi)),as.numeric(svalue(.lati)),col="red",pch=16)
  names(most_similar)="basic"
  .last_run <<- most_similar
  .thresh_resi<<-writeRaster(most_similar,paste(getwd(),"/Results/",svalue(.sitei),"_",svalue(.direci),"/",svalue(.sitei),"_",svalue(.direci),"_threshold.tif",sep=""),overwrite=TRUE)
  
  most_similar[most_similar==0]=NA
  most_similar[1]=0
  names(most_similar)=paste(svalue(.sitei),"_",svalue(.direci),"_threshold",sep="")
  KML(most_similar,col="red",paste(getwd(),"/Results/",svalue(.sitei),"_",svalue(.direci),"/",svalue(.sitei),"_",svalue(.direci),"_threshold",sep=""),overwrite=TRUE)
  
  svalue(.sb)=paste("Finished. See produced plots. The threshold map has been exported to:\n",getwd(),"/Results/",svalue(.sitei),"_",svalue(.direci),"/",svalue(.sitei),"_",svalue(.direci),"_threshold.tif",sep="")
  enabled(.win)=T
  enabled(.soil)=T
}
