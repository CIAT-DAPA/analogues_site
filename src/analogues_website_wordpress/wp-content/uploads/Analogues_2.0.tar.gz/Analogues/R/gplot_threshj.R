gplot_threshj <-
function(){
  enabled(.win)=F
  svalue(.sb)="Applying threshold to identify areas with the highest climatic similartiy for each GCM..."
  print("Applying threshold to identify areas with the highest climatic similartiy for each GCM...")
  if(!(svalue(.shpj)=="Select a shapefile...")){
    .sh=gsub("'","",svalue(.shpj))
    .sh=shapefile(.sh)
  }
  models=list.files(paste(getwd(),"/Data/",svalue(.scen1j),"/",unlist(strsplit(svalue(.di1j),"_"))[1],"_",if(length(unlist(strsplit(svalue(.di1j),"_")))==3)paste(unlist(strsplit(svalue(.di1j),"_"))[2],"_",unlist(strsplit(svalue(.di1j),"_"))[3],sep="") else(unlist(strsplit(svalue(.di1j),"_"))[2]),"/", sep=""))
  all_gcms=paste(getwd(),"/Results/",svalue(.sitej),"_FOTF/Individual_GCMs/",models,".tif",sep="")
  all_gcms=lapply(all_gcms,FUN=raster)
  for(i in 1:length(models)){
    all_gcms[[i]]=all_gcms[[i]]>quantile(all_gcms[[i]],as.numeric(svalue(.threshj)))}
  names(all_gcms)=models
  #x11()
  print(spplot(stack(all_gcms),col.regions=colorRampPalette(c('light grey','dark green'))(2),
               main=paste("FOTF run- ",as.numeric(svalue(.threshj))*100,"% threshold applied, ",svalue(.sitej),sep=""),
               cuts=c(0.5),colorkey = list(labels=list(at = c(0.2,0.8),
                                                       labels = c("Non-analogue", "Analogue"))),maxpixels=10000))
  svalue(.sb)="Applying agreement to identify areas that many models identify as analogues..."
  print("Applying agreement to identify areas that many models identify as analogues...")
  thresh_applied=sum(stack(all_gcms))
  FOTF_agree=(thresh_applied>=as.numeric(svalue(.agreej)))*thresh_applied
  res=stack(list(thresh_applied,FOTF_agree))
  #x11()
  plot(res[[1]], main=paste("FOTF run ",svalue(.sitej), "\n Number of models that satisfy the ",as.numeric(svalue(.threshj))*100,"% threshold",sep=""))
  points(as.numeric(svalue(.longj)),as.numeric(svalue(.latj)),col="red",pch=16)
  if(!(svalue(.shpj)=="Select a shapefile...")){
    plot(.sh,add=T)
  }
  #x11()
  plot(res[[2]],main=paste("FOTF run ",svalue(.sitej), "\n",as.numeric(svalue(.threshj))*100,"% threshold and ",svalue(.agreej)," GCM agreement applied",sep=""))
  points(as.numeric(svalue(.longj)),as.numeric(svalue(.latj)),col="red",pch=16)
  if(!(svalue(.shpj)=="Select a shapefile...")){
    plot(.sh,add=T)
  }
  names(FOTF_agree)="FOTF"
  .last_run <<- FOTF_agree
  .thresh_resi<<-writeRaster(FOTF_agree,paste(getwd(),"/Results/",svalue(.sitej),"_FOTF/FOTF_agreement_",svalue(.sitej),".tif",sep=""),overwrite=TRUE)
  
  FOTF_agree[FOTF_agree==0]=NA
  FOTF_agree[1]=0
  names(FOTF_agree)=paste(svalue(.sitej),"_threshold",sep="")
  KML(FOTF_agree ,col="red",paste(getwd(),"/Results/",svalue(.sitej),"_FOTF/",svalue(.sitej),"_threshold.kml",sep=""),overwrite=TRUE)
  
  enabled(.win)=T
  enabled(.soil)=T
  svalue(.sb)=paste("Finished. See produced plots. The agreement map has been exported to:\n",getwd(),"/Results/FOTF_agreement_",svalue(.sitej),".tif",sep="")
  print(paste("Finished. See produced plots. The agreement map has been exported to:",getwd(),"/Results/",svalue(.sitej),"_FOTF/FOTF_agreement_",svalue(.sitej),".tif",sep=""))
  
}
