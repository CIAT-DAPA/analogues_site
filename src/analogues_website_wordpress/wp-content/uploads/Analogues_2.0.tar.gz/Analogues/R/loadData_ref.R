loadData_ref <-
function (params, numtile) 
{
  training <- list()
  paths <- as.vector(t(outer(str_c(params$env.data, "/", params$scenario[1], 
                                   "/", paste(params$zones[1], "_", params$resolution[1], 
                                              sep = ""), "/", params$model[1], "/", params$period[1], 
                                   "/"), str_c(paste(as.character(lapply(1:length(params$vars), 
                                                                         function(x) strsplit(params$vars, "_")[[x]][1])), "_tif", 
                                                     sep = ""), "/", params$scenario[1], "_", params$period[1], 
                                               "_", params$model[1], "_", params$vars, "_"), FUN = "str_c")))
  training <- lapply(paths, function(x) loadGridsFromFiles(x, 
                                                           params, numtile, paths))
  return(training)
}
