gplot_indiv_resultj <-
function(){
  enabled(.win)=F
  svalue(.sb)=paste("Plotting results for ",svalue(.plot_indivj),"...",sep="")
  if(!(svalue(.shpj)=="Select a shapefile...")){
    .sh=gsub("'","",svalue(.shpj))
    .sh=shapefile(.sh)
  }
  if(svalue(.plot_indivj)=="FOTF"){
    indiv=raster(paste(getwd(),"/Results/",svalue(.sitej),"_FOTF/FOTF_agreement_",svalue(.sitej),".tif",sep=""))
    #x11()
    plot(indiv,main=paste("FOTF run ",svalue(.sitej), "\n",as.numeric(svalue(.threshj))*100,"% threshold and ",svalue(.agreej)," GCM agreement applied",sep=""))
    points(as.numeric(svalue(.longj)),as.numeric(svalue(.latj)),col="red",pch=16)
    if(!(svalue(.shpj)=="Select a shapefile...")){
      plot(.sh,add=T)
    }
  } else {
    indiv=raster(paste(getwd(),"/Results/",svalue(.sitej),"_FOTF/Individual_GCMs/",svalue(.plot_indivj),".tif",sep=""))
    if(!(svalue(.shpj)=="Select a shapefile...")){
      .sh=gsub("'","",svalue(.shpj))
      .sh=shapefile(.sh)
    }
    #x11()
    plot(indiv,main=paste("Backwards analysis '",svalue(.plot_indivj),"' ",svalue(.sitej), "\n raw climatic similarity",sep=""))
    points(as.numeric(svalue(.longj)),as.numeric(svalue(.latj)),col="red",pch=16)
    if(!(svalue(.shpj)=="Select a shapefile...")){
      plot(.sh,add=T)
    }
    #x11()             
    plot(indiv>quantile(indiv,as.numeric(svalue(.threshj))),main=paste("Backwards analysis '",svalue(.plot_indivj),"' ",svalue(.sitej),"\n ",as.numeric(svalue(.threshj))*100,"% threshold applied",sep=""))
    points(as.numeric(svalue(.longj)),as.numeric(svalue(.latj)),col="red",pch=16)
    if(!(svalue(.shpj)=="Select a shapefile...")){
      plot(.sh,add=T)
    }
  }
  enabled(.win)=T
  svalue(.sb)="Finished. See produced plot(s)."
}
