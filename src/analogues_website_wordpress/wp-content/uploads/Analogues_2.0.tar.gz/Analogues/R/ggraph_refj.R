ggraph_refj <-
function(){
  enabled(.win)=F
  svalue(.sb)="Loading parameters..."
  params = createParameters(x=as.numeric(svalue(.longj)),
                            y=as.numeric(svalue(.latj)),
                            method="dummy",
                            direction="dummy",
                            period=c(svalue(.p1j),"dummy"),
                            scenario=c(svalue(.scen1j),"dummy"),
                            model=c("dummy","dummy"),
                            vars=c("prec","tmean"),
                            weights=c("dummy","dummy"),
                            ndivisions=c(12,12),
                            growing.season=c("dummy"),
                            rotation="dummy",
                            zones=c(unlist(strsplit(svalue(.di1j),"_"))[1],"dummy"),
                            resolution=c(if(length(unlist(strsplit(svalue(.di1j),"_")))==3)paste(unlist(strsplit(svalue(.di1j),"_"))[2],"_",unlist(strsplit(svalue(.di1j),"_"))[3],sep="") else(unlist(strsplit(svalue(.di1j),"_"))[2]),"dummy"),
                            env.data=paste(getwd(),"/Data",sep=""),
                            outfile="dummy",
                            ext=".tif",
                            threshold="dummy")
  
  ##load GCM data ref
  svalue(.sb)="Loading GCM data..."
  models=list.files(paste(getwd(),"/Data/",svalue(.scen1j),"/",params$zones[1],"_",params$resolution[1],"/", sep=""))
  
  refs_parallel=function(i){
    params$model[1]=models[i]
    return(ref_vals(params))
  }     
  sfInit(parallel = T, cpus = 4)
  sfExport("params")
  sfExport("models")
  sfExport("sim_index_table")
  sfExport("zones")
  sfLibrary(stringr)
  sfLibrary(raster)
  sfLibrary(Analogues)
  svalue(.sb)="Extracting reference site values..."
  paste("Extracting reference site values")
  var_data=sfLapply(1:length(models),fun = refs_parallel)
  sfStop()
  
  ##load current data ref
  svalue(.sb)="Loading baseline data..."
  params$period[1]="1960_1990"; params$scenario[1]="baseline"; params$model[1]="current"
  baseline_data=ref_vals(params)
  svalue(.sb)="Constructing tables and graphs..."
  
  ###############################################
  #### Graphs and tables of all gcms for prec ###
  ###############################################
  ## making data frame for prec
  prec_gcms=var_data[[1]][[1]]
  for(i in 2:length(models)){
    prec_gcms=cbind.data.frame(prec_gcms,var_data[[i]][[1]])}
  prec_gcms=cbind.data.frame(prec_gcms,baseline_data[1])
  prec_gcms=t(prec_gcms)
  rownames(prec_gcms)=c(models,"current")
  colnames(prec_gcms)=c(month.abb)
  Annual_total=rowSums(prec_gcms)
  prec_gcms=cbind(prec_gcms,Annual_total)
  print("GCM,current and analogue precipitation")
  print(prec_gcms)
  
  #making data frame for tmean
  tmean_gcms=var_data[[1]][[2]]
  for(i in 2:length(models)){
    tmean_gcms=cbind.data.frame(tmean_gcms,var_data[[i]][[2]])}
  tmean_gcms=cbind.data.frame(tmean_gcms,baseline_data[2])/10
  tmean_gcms=t(tmean_gcms)
  rownames(tmean_gcms)=c(models,"current")
  colnames(tmean_gcms)=c(month.abb)
  Average=rowMeans(tmean_gcms)
  options(digits=3)
  tmean_gcms=cbind(tmean_gcms,Average)
  print("GCM,current and analogue mean temperature")
  print(tmean_gcms)
  
  ## Graphing of all GCMs for prec
  #x11()
  prec_data=t(prec_gcms[,1:12])
  matplot(prec_data[,],type="l",col="gray",lty=1,ylab="Precipitation (mm)",
          xlab="",main=paste("Current and future projected precipitation - ",svalue(.sitej)), xaxt="n")
  axis(1, at=1:12, labels=month.name,cex.axis=0.8,las=2)
  lines(prec_data[,'ensemble'],type="l",col="red",lwd=2)
  lines(prec_data[,'current'],type="l",col="blue",lwd=2)
  legend(10,max(prec_data),c("current","ensemble","24 GCMs"),pt.bg="transparent",box.col="transparent",cex=0.9,col=c("blue","red","gray"),lwd=c(2,2,1))
  grid()      
  
  
  ## Graphing of all GCMs for tmean
  #x11()
  tmean_data=t(tmean_gcms[,1:12])
  matplot(tmean_data[,],type="l",col="gray",lty=1,ylab="Mean temperature (degrees Celsius)",
          xlab="",main=paste("Current and future projected mean temperatures - ",svalue(.sitej)), xaxt="n")
  axis(1, at=1:12, labels=month.name,cex.axis=0.8,las=2)
  lines(tmean_data[,'ensemble'],type="l",col="red",lwd=2)
  lines(tmean_data[,'current'],type="l",col="blue",lwd=2)
  legend(10,max(tmean_data),c("current","ensemble","24 GCMs"),pt.bg="transparent",box.col="transparent",cex=0.9,col=c("blue","red","gray"),lwd=c(2,2,1))
  grid()
  
  write.csv( prec_gcms,paste(getwd(),"/Results/",svalue(.sitej),"_FOTF/FOTF_gcms_prec" ,sep=""))
  write.csv(tmean_gcms,paste(getwd(),"/Results/",svalue(.sitej),"_FOTF/FOTF_gcms_tmean",sep=""))
  enabled(.win)=T
  svalue(.sb)="Finished. See the produced graphs to compare current and future tmean and prec at the reference site."
  galert("Finished. See the produced graphs to compare current and future tmean and prec at the reference site.",delay=5)
}
