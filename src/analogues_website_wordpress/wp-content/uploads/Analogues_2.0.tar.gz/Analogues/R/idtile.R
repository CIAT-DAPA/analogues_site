idtile <-
function (params, infotile) 
{
  breaksx = seq(infotile$XMIN, infotile$XMAX, dist(c(infotile$XMIN, 
                                                     infotile$XMAX))[1]/infotile$NCOLS_TILES)
  breaksy = seq(infotile$YMIN, infotile$YMAX, dist(c(infotile$YMIN, 
                                                     infotile$YMAX))[1]/infotile$NROWS_TILES)
  nx = sum(params$x > breaksx)
  ny = sum(params$y > breaksy)
  ntiles = (infotile$NCOLS_TILES * infotile$NROWS_TILES) - 
    1
  tiles = t(cbind(matrix(0:ntiles, ncol = infotile$NROWS_TILES, 
                         nrow = infotile$NCOLS_TILES, byrow = F)))
  return(tiles[ny, nx])
}
