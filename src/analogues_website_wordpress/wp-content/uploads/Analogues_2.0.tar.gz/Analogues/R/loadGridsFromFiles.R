loadGridsFromFiles <-
function (path, params, numtile, paths) 
{
  cat(str_c("loading ", str_sub(path, 1, -2), " \n"))
  if (params$ndivisions[which(path == paths)] >= 2) {
    grid <- do.call(stack, lapply(str_c(path, 1:params$ndivisions[which(path == 
                                                                          paths)], "_", numtile, params$ext), raster))
  }
  else {
    grid <- do.call(stack, lapply(str_c(path, numtile, params$ext), 
                                  raster))
  }
  return(grid)
}
