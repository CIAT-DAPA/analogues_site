gsel_refi <-
function(){
  enabled(.win)=F
  .sh=gsub("'","",svalue(.shp_refi))
  .sh1=shapefile(.sh) 
  svalue(.sb)="Click once on the map to select you reference site..."
  x11()
  plot(extent(.sh1), main="Click once on the map to select your reference site", xlab="Longitude", ylab="Latitude", col="white")
  plot(.sh1, axes=TRUE,col="light grey",add=TRUE)
  paste("Click once on the map to select your reference site")
  .coords=click(.sh1,xy=T)
  points(.coords$x,.coords$y,col="red",pch=16)
  Sys.sleep(1)
  dev.off()
  plot(extent(.sh1), main="Reference site selected. \nContinue entering input parameters", xlab="Longitude", ylab="Latitude", col="white")
  plot(.sh1, axes=TRUE,col="light grey",add=TRUE)
  svalue(.sb)="Reference site selected. Continue entering input parameters."
  svalue(.lati)<-round(.coords$y,digits=3)
  svalue(.longi)<-round(.coords$x,digits=3)
  points(.coords$x,.coords$y,col="red",pch=16)
  enabled(.win)=T  
}
