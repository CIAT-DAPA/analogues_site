createParameters <-
function (x, y, method, model, vars, weights, ndivisions, env.data, 
          ext, direction, growing.season, rotation, period, zones, 
          resolution, scenario, outfile, threshold) 
{params <- list(x = x, y = y, method = method, model = model, 
                direction = direction, growing.season = growing.season, 
                rotation = rotation, env.data = env.data, vars = vars, 
                weights = weights, ext = ext, ndivisions = ndivisions, 
                period = period, zones = zones, resolution = resolution, 
                scenario = scenario, outfile = outfile, threshold = threshold)
 if (length(params$growing.season) == 1) {
   params$growing.season = params$growing.season
 }
 else {
   if (length(params$growing.season) == 2 & params$growing.season[1] == 
         params$growing.season[2]) {
     params$growing.season = params$growing.season[1]
   }
   else {
     if (length(params$growing.season) == 2 & params$growing.season[1] > 
           params$growing.season[2]) {
       params$growing.season = c(params$growing.season[1]:12, 
                                 1:params$growing.season[2])
     }
     else {
       if (length(params$growing.season) == 2 & params$growing.season[1] < 
             params$growing.season[2]) {
         params$growing.season = c(params$growing.season[1]:params$growing.season[2])
       }
       else {
         if (length(params$growing.season) == 4 & params$growing.season[1] > 
               params$growing.season[2]) {
           params$growing.season = c(params$growing.season[1]:12, 
                                     1:params$growing.season[2], params$growing.season[3]:params$growing.season[4])
         }
         else {
           if (length(params$growing.season) == 4 & 
                 params$growing.season[3] > params$growing.season[4]) {
             params$growing.season = c(params$growing.season[1]:params$growing.season[2], 
                                       params$growing.season[3]:12, 1:params$growing.season[4])
           }
           else {
             params$growing.season = c(params$growing.season[1]:params$growing.season[2], 
                                       params$growing.season[3]:params$growing.season[4])
           }
         }
       }
     }
   }
 }
 params$growing.season=unique(params$growing.season)
 return(params)
}
