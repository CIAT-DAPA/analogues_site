ganalogue_by_coords_i <-
function(){
  enabled(.win)=F
  svalue(.sb)="Plotting results..."
  long_r=format(round(as.numeric(svalue(.longi)),digits=3), nsmall = 3)
  lat_r=format(round(as.numeric(svalue(.lati)),digits=3), nsmall = 3)
  long_a=format(round(as.numeric(svalue(.long_abc_i)),digits=3), nsmall = 3)
  lat_a=format(round(as.numeric(svalue(.lat_abc_i)),digits=3), nsmall = 3)
  rs=.thresh_resi
  most_similar=rs>quantile(rs,as.numeric(svalue(.threshi)))
  rs=rs*most_similar
  labi=paste(as.numeric(svalue(.threshi))*100,"% threshold applied- ",svalue(.sitei),"\n",
             if(svalue(.direci)=="backwards"){
               paste("backwards: ",svalue(.model1i),sep="") 
             }else{
               if(svalue(.direci)=="forwards"){
                 paste("forwards: ",svalue(.model2i),sep="") 
               }else{
                 if(svalue(.model1i)==svalue(.model2i)){
                   paste("non-directional: ",svalue(.model1i),sep="") 
                 }else{
                   paste("non-directional: ",svalue(.model1i)," v ",svalue(.model2i),sep="") 
                 }
               }
             },sep="")
  if(!(svalue(.shpi)=="Select a shapefile...")){
    .sh=gsub("'","",svalue(.shpi))
    .sh1=shapefile(.sh)
    plot_sh=function(){plot(.sh1,add=T)
    }
  }else{
    plot_sh=function(){}
  }
  #x11()
  plot(rs, main=paste(labi,"\nAnalogue site: Lat=",lat_a,", Long=",long_a,sep=""))
  plot_sh()
  points(as.numeric(svalue(.longi)),as.numeric(svalue(.lati)),col="red",pch=16)
  points(long_a,lat_a,col="black",pch=16)
  
  #####################################
  svalue(.sb)="Extracting data from the selected analogue site..."
  ##Params
  params = createParameters(x=as.numeric(long_a),
                            y=as.numeric(lat_a),
                            method="dummy",
                            direction=svalue(.direci),
                            period=c("1960_1990","dummy"),
                            scenario=c("baseline","dummy"),
                            model=c("current","dummy"),
                            vars=c("prec","tmean"),
                            weights=c("dummy","dummy"),
                            ndivisions=c(12,12),
                            growing.season=c("dummy"),
                            rotation="dummy",
                            zones=c(unlist(strsplit(svalue(.di1i),"_"))[1],"dummy"),
                            resolution=c(if(length(unlist(strsplit(svalue(.di1i),"_")))==3)paste(unlist(strsplit(svalue(.di1i),"_"))[2],"_",unlist(strsplit(svalue(.di1i),"_"))[3],sep="") else(unlist(strsplit(svalue(.di1i),"_"))[2]),"dummy"),
                            env.data=paste(getwd(),"/Data",sep=""),
                            outfile="dummy",
                            ext=".tif",
                            threshold="dummy")
  
  ##Ref vals for analogue current
  data_analogue_current=ref_vals(params)
  
  ##Ref vals for analogue future
  if (svalue(.direci)=="backwards"){
    scen=svalue(.scen1i)
    mod=svalue(.model1i)
    yr=svalue(.p1i)
  } else {
    if(svalue(.direci)=="forwards"){
      scen=svalue(.scen2i)
      mod=svalue(.model2i)
      yr=svalue(.p2i)
    } else {
      scen=list.files(paste(getwd(),"/Data",sep=""))[-which(list.files(paste(getwd(),"/Data",sep=""))=="baseline")][1]
      mod="ensemble"
      yr=list.files(paste(getwd(),"/Data/",scen,"/",svalue(.di1i),"/",mod,sep=""))[1]
    }
  }
  params$scenario[1]=scen
  params$period[1]=yr
  params$model[1]=mod
  data_analogue_ensemble=ref_vals(params)
  
  
  ##Prec Table for ref site and analogue site
  prec_data_basic=read.csv(paste(getwd(),"/Results/",svalue(.sitei),"_",svalue(.direci),"/ref_basic_prec",sep=""),header=TRUE,row.names=1)
  prec_data_basic=rbind(prec_data_basic[1:2,1:12], data_analogue_current[[1]],data_analogue_ensemble[[1]])
  rownames(prec_data_basic)=c("ref_current",paste("ref_",params$model[1],sep=""),"analogue_current",paste("analogue_",params$model[1],sep=""))
  Annual_total=rowSums(prec_data_basic)
  Lat.=rbind(lat_r,lat_r,lat_a,lat_a)
  Long.=rbind(long_r,long_r,long_a,long_a)
  print("Reference and analogue site precipitation")
  prec_data_basic=print(cbind(prec_data_basic,Annual_total,Lat.,Long.))
  prec_data=t(prec_data_basic[,1:12])
  
  ##Tmean Table for ref site and analogue site
  tmean_data_basic=read.csv(paste(getwd(),"/Results/",svalue(.sitei),"_",svalue(.direci),"/ref_basic_tmean",sep=""),header=TRUE,row.names=1)
  tmean_data_basic=rbind(tmean_data_basic[1:2,1:12], data_analogue_current[[2]]/10,data_analogue_ensemble[[2]]/10)
  rownames(tmean_data_basic)=c("ref_current",paste("ref_",params$model[1],sep=""),"analogue_current",paste("analogue_",params$model[1],sep=""))
  Average=rowMeans(tmean_data_basic)
  Lat.=rbind(lat_r,lat_r,lat_a,lat_a)
  Long.=rbind(long_r,long_r,long_a,long_a)
  print("Reference and analogue site mean temperature")
  tmean_data_basic=print(cbind(tmean_data_basic,Average,Lat.,Long.))
  tmean_data=t(tmean_data_basic[,1:12]) 
  
  ##Prec Graph for ref site and analogue site
  #x11()
  if (svalue(.direci)=="backwards"){
    matplot(prec_data[,],type="l",col="white",lty=1,ylab="Precipitation (mm)",
            xlab="",main=paste("Backwards analysis precipitation- ",svalue(.sitei),"\nAnalogue site: Lat=",lat_a,", Long=",long_a,sep=""), xaxt="n")
    axis(1, at=1:12, labels=month.name,cex.axis=0.8,las=2)
    lines(prec_data[,paste("ref_",params$model[1],sep="")],type="l",col="red",lwd=2)
    lines(prec_data[,'ref_current'],type="l",col="blue",lwd=2)
    lines(prec_data[,'analogue_current'],type="l",col="black",lwd=2)
    legend(9,max(prec_data),c("ref_current",paste("ref_",params$model[1],sep=""),"analogue_current"),pt.bg="transparent",box.col="transparent",cex=0.9,col=c("blue","red","black"),lwd=c(2,2,1))
    grid()
  }
  
  if(svalue(.direci)=="forwards"){
    matplot(prec_data[,],type="l",col="white",lty=1,ylab="Precipitation (mm)",
            xlab="",main=paste("Forwards analysis precipitation - ",svalue(.sitei),"\nAnalogue site: Lat=",lat_a,", Long=",long_a,sep=""), xaxt="n")
    axis(1, at=1:12, labels=month.name,cex.axis=0.8,las=2)
    lines(prec_data[,'ref_current'],type="l",col="blue",lwd=2)
    lines(prec_data[,paste("analogue_",params$model[1],sep="")],type="l",col="black",lwd=2)
    lines(prec_data[,'analogue_current'],type="l",col="grey",lwd=2)
    legend(9,max(prec_data),c("ref_current","analogue_current",paste("analogue_",params$model[1],sep="")),pt.bg="transparent",box.col="transparent",cex=0.9,col=c("blue","grey","black"),lwd=c(2,2,1))
    grid()
  }
  
  if(svalue(.direci)=="none"){
    matplot(prec_data[,],type="l",col="white",lty=1,ylab="Precipitation (mm)",
            xlab="",main=paste("None-directional analysis precipitation - ",svalue(.sitei),"\nAnalogue site: Lat=",lat_a,", Long=",long_a,sep=""), xaxt="n")
    axis(1, at=1:12, labels=month.name,cex.axis=0.8,las=2)
    lines(prec_data[,paste("ref_",params$model[1],sep="")],type="l",col="red",lwd=2)
    lines(prec_data[,'ref_current'],type="l",col="blue",lwd=2)
    lines(prec_data[,paste("analogue_",params$model[1],sep="")],type="l",col="black",lwd=2)
    lines(prec_data[,'analogue_current'],type="l",col="grey",lwd=2)
    legend(9,max(prec_data),c("ref_current",paste("ref_",params$model[1],sep=""),"analogue_current",paste("analogue_",params$model[1],sep="")),pt.bg="transparent",box.col="transparent",cex=0.9,col=c("blue","red","grey","black"),lwd=c(2,2,1))
    grid()
  }
  
  ##Tmean Graph for ref site and analogue site
  #x11()
  if (svalue(.direci)=="backwards"){
    matplot(tmean_data[,],type="l",col="white",lty=1,ylab="Mean temperature (degrees Celsius)",
            xlab="",main=paste("Backwards analysis temperature- ",svalue(.sitei),"\nAnalogue site: Lat=",lat_a,", Long=",long_a,sep=""), xaxt="n")
    axis(1, at=1:12, labels=month.name,cex.axis=0.8,las=2)
    lines(tmean_data[,paste("ref_",params$model[1],sep="")],type="l",col="red",lwd=2)
    lines(tmean_data[,'ref_current'],type="l",col="blue",lwd=2)
    lines(tmean_data[,'analogue_current'],type="l",col="black",lwd=2)
    legend(9,max(tmean_data),c("ref_current",paste("ref_",params$model[1],sep=""),"analogue_current"),pt.bg="transparent",box.col="transparent",cex=0.9,col=c("blue","red","black"),lwd=c(2,2,1))
    grid()
  }
  
  if(svalue(.direci)=="forwards"){
    matplot(tmean_data[,],type="l",col="white",lty=1,ylab="Mean temperature (degrees Celsius)",
            xlab="",main=paste("Forwards analysis temperature- ",svalue(.sitei),"\nAnalogue site: Lat=",lat_a,", Long=",long_a,sep=""), xaxt="n")
    axis(1, at=1:12, labels=month.name,cex.axis=0.8,las=2)
    lines(tmean_data[,'ref_current'],type="l",col="blue",lwd=2)
    lines(tmean_data[,paste("analogue_",params$model[1],sep="")],type="l",col="black",lwd=2)
    lines(tmean_data[,'analogue_current'],type="l",col="grey",lwd=2)
    legend(9,max(tmean_data),c("ref_current","analogue_current",paste("analogue_",params$model[1],sep="")),pt.bg="transparent",box.col="transparent",cex=0.9,col=c("blue","grey","black"),lwd=c(2,2,1))
    grid()
  }
  
  if(svalue(.direci)=="none"){
    matplot(tmean_data[,],type="l",col="white",lty=1,ylab="Mean temperature (degrees Celsius)",
            xlab="",main=paste("Non-directional analysis temperature- ",svalue(.sitei),"\nAnalogue site: Lat=",lat_a,", Long=",long_a,sep=""), xaxt="n")
    axis(1, at=1:12, labels=month.name,cex.axis=0.8,las=2)
    lines(tmean_data[,paste("ref_",params$model[1],sep="")],type="l",col="red",lwd=2)
    lines(tmean_data[,'ref_current'],type="l",col="blue",lwd=2)
    lines(tmean_data[,paste("analogue_",params$model[1],sep="")],type="l",col="black",lwd=2)
    lines(tmean_data[,'analogue_current'],type="l",col="grey",lwd=2)
    legend(9,max(tmean_data),c("ref_current",paste("ref_",params$model[1],sep=""),"analogue_current",paste("analogue_",params$model[1],sep="")),pt.bg="transparent",box.col="transparent",cex=0.9,col=c("blue","red","grey","black"),lwd=c(2,2,1))
    grid()
  }
  enabled(.win)=T
  svalue(.sb)="Finished. See the produced graphs to compare prec and tmean values of the reference site and selected analogue."
}
