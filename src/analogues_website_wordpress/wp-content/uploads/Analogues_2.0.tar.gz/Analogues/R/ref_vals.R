ref_vals <-
function (params) 
{
  infotile = zones[which(row.names(zones) == paste(params$zones[1], 
                                                   "_", params$resolution[1], sep = "")), ]
  ref_tile = idtile(params, infotile)
  training_ref = loadData_ref(params, ref_tile)
  val_ref = list()
  for (i in 1:length(params$vars)) {
    val_ref[[i]] = as.integer(extract(training_ref[[i]], 
                                      cbind(params$x, params$y)))
  }
  return(val_ref)
}
