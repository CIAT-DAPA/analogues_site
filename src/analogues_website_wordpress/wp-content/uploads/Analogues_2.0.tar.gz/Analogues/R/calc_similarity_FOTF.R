calc_similarity_FOTF<-
  function(params)
  {
    infotile = zones[which(row.names(zones) == paste(params$zones[1], "_", params$resolution[1], sep = "")), ]
    total_tiles = (infotile$NCOLS_TILES * infotile$NROWS_TILES) - 1
    fotf_models=list.files(paste(params$env.data,"/",params$scenario[1],"/",params$zones[1],"_",params$resolution[1],sep=""))
    
    ## parallel
    refs_parallel=function(i){
      params$model[1]=fotf_models[i]
      return(ref_vals(params))
    }     
    
    wrapper = function(i) {
      training_targ = loadData_targ(params, i)
      if (params$rotation == "none") {## | sum(!is.na(training_targ[[1]][, 1])) <= 100necessary??
        training_targ = training_targ
      } else {
        training_targ = rota_stack(val_ref, training_targ, params)
      }
      return(similarity(training_targ, val_ref, params))
    }
    
    infotile_2 = zones[which(row.names(zones) == paste(params$zones[2], "_", params$resolution[2], sep = "")), ]
    total_tiles_2 = (infotile_2$NCOLS_TILES * infotile_2$NROWS_TILES) - 1
    
    sfInit(parallel = T, cpus = 4)
    sfExport("params")
    sfExport("fotf_models")
    sfExport("sim_index_table")
    sfExport("zones")
    sfLibrary(stringr)
    sfLibrary(raster)
    sfLibrary(Analogues)
    cat("Extracting ref vals...\n")
    val_refs_fotf=sfLapply(1:length(fotf_models),fun = refs_parallel)
    sfStop()
    
    if (total_tiles_2 == 0){
      for (m in 1:length(fotf_models)){
        cat(paste("Calculating similarity for",fotf_models[m], "...\n"))
        val_ref=val_refs_fotf[[m]]        
        merged_tiles= wrapper(0)
        writeRaster(merged_tiles, paste(params$outfile, "/",fotf_models[m],".tif", sep = ""), overwrite = TRUE)
      }
      
    }else{
      sfInit(parallel = T, cpus = if (total_tiles_2<=25){total_tiles_2 + 1}else{26})
      sfExport("params")
      sfExport("val_refs_fotf")
      sfExport("sim_index_table")
      sfLibrary(stringr)
      sfLibrary(raster)
      sfLibrary(Analogues)
      for (m in 1:length(fotf_models)){
        cat(paste("Calculating similarity for",fotf_models[m], "...\n"))
        val_ref=val_refs_fotf[[m]]        
        res_tiles=sfLapply(0:total_tiles_2,fun = wrapper)
        if(length(res_tiles)>140){
          m1=res_tiles[1:100]                 ; m1=do.call(merge,m1)
          m2=res_tiles[101:length(res_tiles)]; m2=do.call(merge,m2)
          merged_tiles=c(m1,m2)
          merged_tiles=do.call(merge,merged_tiles)
        }else{
          merged_tiles=do.call(merge,res_tiles)
        }
        writeRaster(merged_tiles, paste(params$outfile, "/",fotf_models[m],".tif", sep = ""), overwrite = TRUE)
      }
      sfStop()
    }
  }

